CREATE PACKAGE BODY "PKG_CM_DM_KHOI_KCB" AS

    PROCEDURE verify_common_dm_khoi_kcb (
        p_arr           IN table_cm_dm_khoi_kcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                DELETE common_dm_khoi_kcb_new WHERE
                    id = p_arr(p_index).id;

                INSERT INTO common_dm_khoi_kcb_new (
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).ma,
                    p_arr(p_index).ten,
                    p_arr(p_index).dm_dt_kcb_id,
                    p_arr(p_index).nhom,
                    p_arr(p_index).tinh_trang
                );

            END;
        END LOOP;
		/**
        DELETE common_dm_khoi_kcb_diff WHERE
            id IN (
                SELECT
                    id
                FROM
                    (
                        SELECT
                            id,
                            ma,
                            ten,
                            dm_dt_kcb_id,
                            nhom,
                            tinh_trang
                        FROM
                            common_dm_khoi_kcb_new
                        MINUS
                        SELECT
                            id,
                            ma,
                            ten,
                            dm_dt_kcb_id,
                            nhom,
                            tinh_trang
                        FROM
                            common_dm_khoi_kcb
                    ) diff
            );

        INSERT INTO common_dm_khoi_kcb_diff (
            verify_date,
            id,
            ma,
            ten,
            dm_dt_kcb_id,
            nhom,
            tinh_trang
        ) SELECT
            SYSDATE,
            id,
            ma,
            ten,
            dm_dt_kcb_id,
            nhom,
            tinh_trang
        FROM
            (
                SELECT
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                FROM
                    common_dm_khoi_kcb_new
                MINUS
                SELECT
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                FROM
                    common_dm_khoi_kcb
            ) diff;

        DELETE common_dm_khoi_kcb_new;
		*/

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode
                 || '-VERIFY_COMMON_DM_KHOI_KCB-'
                 || p_arr(p_index).id
                 || '-'
                 || p_index;

                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

--    PROCEDURE cud_common_dm_khoi_kcb (
--        p_id             IN NUMBER,
--        p_ma             IN VARCHAR2,
--        p_ten            IN VARCHAR2,
--        p_dm_dt_kcb_id   IN NUMBER DEFAULT NULL,
--        p_nhom           IN VARCHAR2,
--        p_tinh_trang     IN NUMBER,
--        p_output_code    OUT VARCHAR2,
--        p_output_msg     OUT VARCHAR2
--    ) IS
--        id_value   NUMBER;
--    BEGIN
--        IF
--            p_id IS NOT NULL
--        THEN
--    --update
--            UPDATE common_dm_khoi_kcb
--                SET
--                    ma = p_ma,
--                    ten = p_ten,
--                    dm_dt_kcb_id = p_dm_dt_kcb_id,
--                    nhom = p_nhom,
--                    tinh_trang = p_tinh_trang,
--                    updated_date = SYSDATE
--            WHERE
--                id = p_id;
--
----        p_output_msg := 'Update success id =' || p_id;
--
--            IF
--                SQL%rowcount > 0
--            THEN
--                p_output_msg := 'Update success id =' || p_id;
--            ELSE
--                p_output_msg := '0 rows affected. id =' || p_id;
--            END IF;
--
--        ELSE
--    --insert
--            SELECT
--                CASE
--                    WHEN MAX(id) IS NULL THEN 1
--                    ELSE ( MAX(id) + 1 )
--                END
--            INTO
--                id_value
--            FROM
--                common_dm_khoi_kcb;
--
--            INSERT INTO common_dm_khoi_kcb (
--                id,
--                ma,
--                ten,
--                dm_dt_kcb_id,
--                nhom,
--                tinh_trang,
--                created_date
--            ) VALUES (
--                id_value,
--                p_ma,
--                p_ten,
--                p_dm_dt_kcb_id,
--                p_nhom,
--                p_tinh_trang,
--                SYSDATE
--            );
--
--            p_output_msg := 'Insert success id=' || id_value;
--        END IF;
--
--        COMMIT;
--        p_output_code := '00';
--    EXCEPTION
--        WHEN OTHERS THEN
--            p_output_code := sqlcode;
--            p_output_msg := substr(
--                sqlerrm,
--                1,
--                2000
--            );
--            INSERT INTO procedure_log (
--                id,
--                error_code,
--                message,
--                id_entity
--            ) VALUES (
--                (
--                    SELECT
--                        MAX(id) + 1
--                    FROM
--                        procedure_log
--                ),
--                p_output_code,
--                p_output_msg,
--                p_id
--            );
--
--            COMMIT;
--    END;

--    PROCEDURE sync_cm_dm_khoi_kcb (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_khoi_kcb WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_khoi_kcb_diff
--            );
--
--        INSERT INTO common_dm_khoi_kcb (
--            id,
--            ma,
--            ten,
--            dm_dt_kcb_id,
--            nhom,
--            tinh_trang,
--            created_date,
--            updated_date
--        ) SELECT
--            id,
--            ma,
--            ten,
--            dm_dt_kcb_id,
--            nhom,
--            tinh_trang,
--            created_date,
--            updated_date
--        FROM
--            common_dm_khoi_kcb_diff;
--
--        DELETE common_dm_khoi_kcb_diff;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-SYNC_CM_DM_KHOI_KCB';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;

--    PROCEDURE sync_cm_dm_khoi_kcb_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_khoi_kcb WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_khoi_kcb_diff
--                WHERE
--                    id = p_id
--            );
--
--        INSERT INTO common_dm_khoi_kcb (
--            id,
--            ma,
--            ten,
--            dm_dt_kcb_id,
--            nhom,
--            tinh_trang,
--            created_date,
--            updated_date
--        ) SELECT
--            id,
--            ma,
--            ten,
--            dm_dt_kcb_id,
--            nhom,
--            tinh_trang,
--            created_date,
--            updated_date
--        FROM
--            common_dm_khoi_kcb_diff
--        WHERE
--            id = p_id;
--
--        DELETE common_dm_khoi_kcb_diff WHERE
--            id = p_id;
--
--        p_output_code := '00';
--        p_output_msg := 'Success';
--        INSERT INTO procedure_log (
--            id,
--            error_code,
--            message,
--            id_entity
--        ) VALUES (
--            (
--                SELECT
--                    MAX(id) + 1
--                FROM
--                    procedure_log
--            ),
--            p_output_code,
--            p_output_msg,
--            1
--        );
--
--        COMMIT;
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-SYNC_CM_DM_KHOI_KCB_ID';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;

    PROCEDURE  get_list_cm_dm_khoi_kcb_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    ) AS
        p_count        NUMBER(19) := 0;
        p_output_msg   VARCHAR2(2000);
    BEGIN
        SELECT
            COUNT(*)
        INTO
            p_count
        FROM
            common_dm_khoi_kcb_diff;

        p_out_total_row := p_count;
        p_out_total_page := floor(p_out_total_row / p_per_page);
        OPEN p_out_table FOR
            SELECT
                *
            FROM
                (
                    SELECT
                        ROW_NUMBER() OVER(
                            ORDER BY verify_id
                        ) AS seqnum,
                        a.verify_id,
                        a.verify_date,
                        a.id,
                        a.updated_date
                    FROM
                        common_dm_khoi_kcb_diff a
                    WHERE
                        1 = 1
                ) temp
            WHERE
                    seqnum > ( ( p_page - 1 ) * p_per_page )
                AND
                    seqnum <= ( ( p_page ) * p_per_page );

        IF
            MOD(
                p_out_total_row,
                p_per_page
            ) > 0
        THEN
            p_out_total_page := p_out_total_page + 1;
        END IF;

        p_output_code := '00';
    EXCEPTION
        WHEN OTHERS THEN
            p_output_code := sqlcode;
            p_output_msg := substr(
                sqlerrm,
                1,
                1500
            );
            p_out_table := NULL;
            p_out_total_page := 0;
            p_out_total_row := 0;
            p_output_msg := p_output_msg
             || '-get_list_cm_dm_khoi_kcb_diff-,p_per_page='
             || p_per_page
             || ',p_page='
             || p_page;
            INSERT INTO procedure_log (
                id,
                error_code,
                message,
                id_entity
            ) VALUES (
                (
                    SELECT
                        MAX(id) + 1
                    FROM
                        procedure_log
                ),
                p_output_code,
                p_output_msg,
                0
            );

            COMMIT;
    END;

    PROCEDURE sync_direct_common_dm_khoi_kcb (
        p_arr           IN table_cm_dm_khoi_kcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                INSERT INTO common_dm_khoi_kcb (
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).ma,
                    p_arr(p_index).ten,
                    p_arr(p_index).dm_dt_kcb_id,
                    p_arr(p_index).nhom,
                    p_arr(p_index).tinh_trang
                );

            END;
        END LOOP;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode
                 || '-sync_direct_common_dm_khoi_kcb-'
                 || p_arr(p_index).id
                 || '-'
                 || p_index;

                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

    PROCEDURE del_cm_dm_khoi_kcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_khoi_kcb;

        DELETE common_dm_khoi_kcb_diff;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode || '-del_cm_dm_khoi_kcb';
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    1
                );

                COMMIT;
            END;
    END;

    PROCEDURE exec_verify_common_dm_khoi_kcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_khoi_kcb_diff;

        INSERT INTO common_dm_khoi_kcb_diff (
            verify_date,
            verify_type,
            id,
            ma,
            ten,
            dm_dt_kcb_id,
            nhom,
            tinh_trang
        ) SELECT
            SYSDATE,
            2,
            id,
            ma,
            ten,
            dm_dt_kcb_id,
            nhom,
            tinh_trang
        FROM
            (
                SELECT
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                FROM
                    common_dm_khoi_kcb_new
                MINUS
                SELECT
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                FROM
                    common_dm_khoi_kcb
            ) diff;

        INSERT INTO common_dm_khoi_kcb_diff (
            verify_date,
            verify_type,
            id,
            ma,
            ten,
            dm_dt_kcb_id,
            nhom,
            tinh_trang
        ) SELECT
            SYSDATE,
            1,
            id,
            ma,
            ten,
            dm_dt_kcb_id,
            nhom,
            tinh_trang
        FROM
            (
                SELECT
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                FROM
                    common_dm_khoi_kcb
                MINUS
                SELECT
                    id,
                    ma,
                    ten,
                    dm_dt_kcb_id,
                    nhom,
                    tinh_trang
                FROM
                    common_dm_khoi_kcb_new
            ) diff;

        DELETE common_dm_khoi_kcb_new;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode || '-exec_VERIFY_COMMON_DM_KHOI_KCB-';
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    0
                );

                COMMIT;
            END;
    END;

END pkg_cm_dm_khoi_kcb;
/
