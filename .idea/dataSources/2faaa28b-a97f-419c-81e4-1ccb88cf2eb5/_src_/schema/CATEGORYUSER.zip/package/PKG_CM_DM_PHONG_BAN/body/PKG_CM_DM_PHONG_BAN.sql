CREATE PACKAGE BODY                "PKG_CM_DM_PHONG_BAN" AS

    PROCEDURE verify_common_dm_phong_ban (
        p_arr           IN table_cm_dm_phong_ban,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                INSERT INTO common_dm_phong_ban_new (
                    id,
                    ten_tieng_viet,
                    ten_tieng_anh,
                    ten_viet_tat,
                    tinh_thanh_id,
                    dia_chi,
                    dien_thoai,
                    email,
                    fax,
                    ma_so_thue,
                    db_name,
                    last_update,
                    ma_don_vi,
                    donvi_cha_id,
                    cap_don_vi,
                    loai_hinh,
                    ma_kcb,
                    so_tai_khoan,
                    ngan_hang,
                    loai_hinh_don_vi,
                    sl_diem_kho,
                    co_quan_tong_cuc,
                    xa_phuong_id,
                    stt_cap,
                    pc_khu_vuc
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).ten_tieng_viet,
                    p_arr(p_index).ten_tieng_anh,
                    p_arr(p_index).ten_viet_tat,
                    p_arr(p_index).tinh_thanh_id,
                    p_arr(p_index).dia_chi,
                    p_arr(p_index).dien_thoai,
                    p_arr(p_index).email,
                    p_arr(p_index).fax,
                    p_arr(p_index).ma_so_thue,
                    p_arr(p_index).db_name,
                    p_arr(p_index).last_update,
                    p_arr(p_index).ma_don_vi,
                    p_arr(p_index).donvi_cha_id,
                    p_arr(p_index).cap_don_vi,
                    p_arr(p_index).loai_hinh,
                    p_arr(p_index).ma_kcb,
                    p_arr(p_index).so_tai_khoan,
                    p_arr(p_index).ngan_hang,
                    p_arr(p_index).loai_hinh_don_vi,
                    p_arr(p_index).sl_diem_kho,
                    p_arr(p_index).co_quan_tong_cuc,
                    p_arr(p_index).xa_phuong_id,
                    p_arr(p_index).stt_cap,
                    p_arr(p_index).pc_khu_vuc
                );

            END;
        END LOOP;        
        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := 'verify_common_dm_phong_ban-'
                 || substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

	--exec

    PROCEDURE exec_verify_cm_dm_phong_ban (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_phong_ban_diff;

        INSERT INTO common_dm_phong_ban_diff (
            verify_date,
            verify_type,
            id,
            ten_tieng_viet,
            ten_tieng_anh,
            ten_viet_tat,
            tinh_thanh_id,
            dia_chi,
            dien_thoai,
            email,
            fax,
            ma_so_thue,
            db_name,
            last_update,
            ma_don_vi,
            donvi_cha_id,
            cap_don_vi,
            loai_hinh,
            ma_kcb,
            so_tai_khoan,
            ngan_hang,
            loai_hinh_don_vi,
            sl_diem_kho,
            co_quan_tong_cuc,
            xa_phuong_id,
            stt_cap,
            pc_khu_vuc
        ) SELECT
            SYSDATE,
            2,
            id,
            ten_tieng_viet,
            ten_tieng_anh,
            ten_viet_tat,
            tinh_thanh_id,
            dia_chi,
            dien_thoai,
            email,
            fax,
            ma_so_thue,
            db_name,
            last_update,
            ma_don_vi,
            donvi_cha_id,
            cap_don_vi,
            loai_hinh,
            ma_kcb,
            so_tai_khoan,
            ngan_hang,
            loai_hinh_don_vi,
            sl_diem_kho,
            co_quan_tong_cuc,
            xa_phuong_id,
            stt_cap,
            pc_khu_vuc
        FROM
            (
                SELECT
                    id,
                    ten_tieng_viet,
                    ten_tieng_anh,
                    ten_viet_tat,
                    tinh_thanh_id,
                    dia_chi,
                    dien_thoai,
                    email,
                    fax,
                    ma_so_thue,
                    db_name,
                    last_update,
                    ma_don_vi,
                    donvi_cha_id,
                    cap_don_vi,
                    loai_hinh,
                    ma_kcb,
                    so_tai_khoan,
                    ngan_hang,
                    loai_hinh_don_vi,
                    sl_diem_kho,
                    co_quan_tong_cuc,
                    xa_phuong_id,
                    stt_cap,
                    pc_khu_vuc
                FROM
                    common_dm_phong_ban_new
                MINUS
                SELECT
                    id,
                    ten_tieng_viet,
                    ten_tieng_anh,
                    ten_viet_tat,
                    tinh_thanh_id,
                    dia_chi,
                    dien_thoai,
                    email,
                    fax,
                    ma_so_thue,
                    db_name,
                    last_update,
                    ma_don_vi,
                    donvi_cha_id,
                    cap_don_vi,
                    loai_hinh,
                    ma_kcb,
                    so_tai_khoan,
                    ngan_hang,
                    loai_hinh_don_vi,
                    sl_diem_kho,
                    co_quan_tong_cuc,
                    xa_phuong_id,
                    stt_cap,
                    pc_khu_vuc
                FROM
                    common_dm_phong_ban
            ) diff;

        INSERT INTO common_dm_phong_ban_diff (
            verify_date,
            verify_type,
            id,
            ten_tieng_viet,
            ten_tieng_anh,
            ten_viet_tat,
            tinh_thanh_id,
            dia_chi,
            dien_thoai,
            email,
            fax,
            ma_so_thue,
            db_name,
            last_update,
            ma_don_vi,
            donvi_cha_id,
            cap_don_vi,
            loai_hinh,
            ma_kcb,
            so_tai_khoan,
            ngan_hang,
            loai_hinh_don_vi,
            sl_diem_kho,
            co_quan_tong_cuc,
            xa_phuong_id,
            stt_cap,
            pc_khu_vuc
        ) SELECT
            SYSDATE,
            1,
            id,
            ten_tieng_viet,
            ten_tieng_anh,
            ten_viet_tat,
            tinh_thanh_id,
            dia_chi,
            dien_thoai,
            email,
            fax,
            ma_so_thue,
            db_name,
            last_update,
            ma_don_vi,
            donvi_cha_id,
            cap_don_vi,
            loai_hinh,
            ma_kcb,
            so_tai_khoan,
            ngan_hang,
            loai_hinh_don_vi,
            sl_diem_kho,
            co_quan_tong_cuc,
            xa_phuong_id,
            stt_cap,
            pc_khu_vuc
        FROM
            (
                SELECT
                    id,
                    ten_tieng_viet,
                    ten_tieng_anh,
                    ten_viet_tat,
                    tinh_thanh_id,
                    dia_chi,
                    dien_thoai,
                    email,
                    fax,
                    ma_so_thue,
                    db_name,
                    last_update,
                    ma_don_vi,
                    donvi_cha_id,
                    cap_don_vi,
                    loai_hinh,
                    ma_kcb,
                    so_tai_khoan,
                    ngan_hang,
                    loai_hinh_don_vi,
                    sl_diem_kho,
                    co_quan_tong_cuc,
                    xa_phuong_id,
                    stt_cap,
                    pc_khu_vuc
                FROM
                    common_dm_phong_ban
                MINUS
                SELECT
                    id,
                    ten_tieng_viet,
                    ten_tieng_anh,
                    ten_viet_tat,
                    tinh_thanh_id,
                    dia_chi,
                    dien_thoai,
                    email,
                    fax,
                    ma_so_thue,
                    db_name,
                    last_update,
                    ma_don_vi,
                    donvi_cha_id,
                    cap_don_vi,
                    loai_hinh,
                    ma_kcb,
                    so_tai_khoan,
                    ngan_hang,
                    loai_hinh_don_vi,
                    sl_diem_kho,
                    co_quan_tong_cuc,
                    xa_phuong_id,
                    stt_cap,
                    pc_khu_vuc
                FROM
                    common_dm_phong_ban_new
            ) diff;

        DELETE common_dm_phong_ban_new;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := 'exec_verify_common_dm_phong_ban-'
                 || substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    0
                );

                COMMIT;
            END;
    END;
--
--    PROCEDURE sync_cm_dm_phong_ban (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_phong_ban WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_phong_ban_diff
--            );
--
--        INSERT INTO common_dm_phong_ban (
--            id,
--            ten_tieng_viet,
--            ten_tieng_anh,
--            ten_viet_tat,
--            tinh_thanh_id,
--            dia_chi,
--            dien_thoai,
--            email,
--            fax,
--            ma_so_thue,
--            db_name,
--            last_update,
--            ma_don_vi,
--            donvi_cha_id,
--            cap_don_vi,
--            loai_hinh,
--            ma_kcb,
--            so_tai_khoan,
--            ngan_hang,
--            loai_hinh_don_vi,
--            sl_diem_kho,
--            co_quan_tong_cuc,
--            xa_phuong_id,
--            stt_cap,
--            pc_khu_vuc
--        ) SELECT
--            id,
--            ten_tieng_viet,
--            ten_tieng_anh,
--            ten_viet_tat,
--            tinh_thanh_id,
--            dia_chi,
--            dien_thoai,
--            email,
--            fax,
--            ma_so_thue,
--            db_name,
--            last_update,
--            ma_don_vi,
--            donvi_cha_id,
--            cap_don_vi,
--            loai_hinh,
--            ma_kcb,
--            so_tai_khoan,
--            ngan_hang,
--            loai_hinh_don_vi,
--            sl_diem_kho,
--            co_quan_tong_cuc,
--            xa_phuong_id,
--            stt_cap,
--            pc_khu_vuc
--        FROM
--            common_dm_phong_ban_diff;
--
--        DELETE common_dm_phong_ban_diff;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-sync_cm_dm_phong_ban-';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;

    PROCEDURE sync_direct_cm_dm_pb (
        p_arr           IN table_cm_dm_phong_ban,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                INSERT INTO common_dm_phong_ban (
                    id,
                    ten_tieng_viet,
                    ten_tieng_anh,
                    ten_viet_tat,
                    tinh_thanh_id,
                    dia_chi,
                    dien_thoai,
                    email,
                    fax,
                    ma_so_thue,
                    db_name,
                    last_update,
                    ma_don_vi,
                    donvi_cha_id,
                    cap_don_vi,
                    loai_hinh,
                    ma_kcb,
                    so_tai_khoan,
                    ngan_hang,
                    loai_hinh_don_vi,
                    sl_diem_kho,
                    co_quan_tong_cuc,
                    xa_phuong_id,
                    stt_cap,
                    pc_khu_vuc
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).ten_tieng_viet,
                    p_arr(p_index).ten_tieng_anh,
                    p_arr(p_index).ten_viet_tat,
                    p_arr(p_index).tinh_thanh_id,
                    p_arr(p_index).dia_chi,
                    p_arr(p_index).dien_thoai,
                    p_arr(p_index).email,
                    p_arr(p_index).fax,
                    p_arr(p_index).ma_so_thue,
                    p_arr(p_index).db_name,
                    p_arr(p_index).last_update,
                    p_arr(p_index).ma_don_vi,
                    p_arr(p_index).donvi_cha_id,
                    p_arr(p_index).cap_don_vi,
                    p_arr(p_index).loai_hinh,
                    p_arr(p_index).ma_kcb,
                    p_arr(p_index).so_tai_khoan,
                    p_arr(p_index).ngan_hang,
                    p_arr(p_index).loai_hinh_don_vi,
                    p_arr(p_index).sl_diem_kho,
                    p_arr(p_index).co_quan_tong_cuc,
                    p_arr(p_index).xa_phuong_id,
                    p_arr(p_index).stt_cap,
                    p_arr(p_index).pc_khu_vuc
                );

            END;
        END LOOP;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := 'sync_direct_cm_dm_pb-'
                 || substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

    PROCEDURE del_cm_dm_phong_ban (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_phong_ban;

        DELETE common_dm_phong_ban_diff;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode || '-del_cm_dm_phong_ban-';
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    1
                );

                COMMIT;
            END;
    END;

END pkg_cm_dm_phong_ban;
/
