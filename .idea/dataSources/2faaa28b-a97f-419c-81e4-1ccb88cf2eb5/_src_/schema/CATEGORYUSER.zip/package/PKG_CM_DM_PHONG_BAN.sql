CREATE PACKAGE "PKG_CM_DM_PHONG_BAN" AS
    PROCEDURE verify_common_dm_phong_ban (
        p_arr           IN table_cm_dm_phong_ban,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

    PROCEDURE exec_verify_cm_dm_phong_ban (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

--    PROCEDURE sync_cm_dm_phong_ban (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );

    PROCEDURE sync_direct_cm_dm_pb (
        p_arr           IN table_cm_dm_phong_ban,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

    PROCEDURE del_cm_dm_phong_ban (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

END pkg_cm_dm_phong_ban;
/
