CREATE PACKAGE                "PKG_CM_DM_KHOI_KCB" AS
    PROCEDURE verify_common_dm_khoi_kcb (
        p_arr           IN table_cm_dm_khoi_kcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

--    PROCEDURE cud_common_dm_khoi_kcb (
--        p_id             IN NUMBER,
--        p_ma             IN VARCHAR2,
--        p_ten            IN VARCHAR2,
--        p_dm_dt_kcb_id   IN NUMBER DEFAULT NULL,
--        p_nhom           IN VARCHAR2,
--        p_tinh_trang     IN NUMBER,
--        p_output_code    OUT VARCHAR2,
--        p_output_msg     OUT VARCHAR2
--    );

--    PROCEDURE sync_cm_dm_khoi_kcb (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );
--
--    PROCEDURE sync_cm_dm_khoi_kcb_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );

    PROCEDURE get_list_cm_dm_khoi_kcb_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    );

    PROCEDURE sync_direct_common_dm_khoi_kcb (
        p_arr           IN table_cm_dm_khoi_kcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

    PROCEDURE del_cm_dm_khoi_kcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

	PROCEDURE exec_verify_common_dm_khoi_kcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

END pkg_cm_dm_khoi_kcb;
/
