CREATE PACKAGE BODY "PKG_CM_DM_KHOI_QL" AS

    PROCEDURE verify_common_dm_khoi_ql (
        p_arr           IN table_cm_dm_khoi_ql,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                DELETE common_dm_khoi_quan_ly_new WHERE
                    id = p_arr(p_index).id;

                INSERT INTO common_dm_khoi_quan_ly_new (
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).created_date,
                    p_arr(p_index).updated_date,
                    p_arr(p_index).ma,
                    p_arr(p_index).ten,
                    p_arr(p_index).dm_bhxh_id,
                    p_arr(p_index).dm_khoi_kcb_id,
                    p_arr(p_index).dm_khoi_tk_id,
                    p_arr(p_index).status,
                    p_arr(p_index).bhyt
                );

            END;
        END LOOP;
		/*
        DELETE common_dm_khoi_quan_ly_diff WHERE
            id IN (
                SELECT
                    id
                FROM
                    (
                        SELECT
                            id,
                            created_date,
                            updated_date,
                            ma,
                            ten,
                            dm_bhxh_id,
                            dm_khoi_kcb_id,
                            dm_khoi_tk_id,
                            status,
                            bhyt
                        FROM
                            common_dm_khoi_quan_ly_new
                        MINUS
                        SELECT
                            id,
                            created_date,
                            updated_date,
                            ma,
                            ten,
                            dm_bhxh_id,
                            dm_khoi_kcb_id,
                            dm_khoi_tk_id,
                            status,
                            bhyt
                        FROM
                            common_dm_khoi_quan_ly
                    ) diff
            );

        INSERT INTO common_dm_khoi_quan_ly_diff (
            verify_date,
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        ) SELECT
            SYSDATE,
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        FROM
            (
                SELECT
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                FROM
                    common_dm_khoi_quan_ly_new
                MINUS
                SELECT
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                FROM
                    common_dm_khoi_quan_ly
            ) diff;

        DELETE common_dm_khoi_quan_ly_new;
		*/

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := 'VERIFY_COMMON_DM_KHOI_QL-'
                 || substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

	--exec

    PROCEDURE  exec_verify_common_dm_khoi_ql (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_khoi_quan_ly_diff;

        INSERT INTO common_dm_khoi_quan_ly_diff (
            verify_date,
            verify_type,
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        ) SELECT
            SYSDATE,
            2,
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        FROM
            (
                SELECT
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                FROM
                    common_dm_khoi_quan_ly_new
                MINUS
                SELECT
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                FROM
                    common_dm_khoi_quan_ly
            ) diff;

        INSERT INTO common_dm_khoi_quan_ly_diff (
            verify_date,
            verify_type,
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        ) SELECT
            SYSDATE,
            1,
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        FROM
            (
                SELECT
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                FROM
                    common_dm_khoi_quan_ly
                MINUS
                SELECT
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                FROM
                    common_dm_khoi_quan_ly_new
            ) diff;

        DELETE common_dm_khoi_quan_ly_new;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := 'exec_verify_common_dm_khoi_ql-'
                 || substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    0
                );

                COMMIT;
            END;
    END;
--
--    PROCEDURE cud_common_dm_khoi_quan_ly (
--        p_id               IN NUMBER,
--        p_ma               IN VARCHAR2,
--        p_ten              IN VARCHAR2,
--        p_dm_bhxh_id       IN NUMBER,
--        p_dm_khoi_kcb_id   IN NUMBER,
--        p_dm_khoi_tk_id    IN NUMBER,
--        p_status           IN NUMBER,
--        p_bhyt             IN NUMBER,
--        p_output_code      OUT VARCHAR2,
--        p_output_msg       OUT VARCHAR2
--    ) IS
--        id_value   NUMBER;
--    BEGIN
--        IF
--            p_id IS NOT NULL
--        THEN
--            UPDATE common_dm_khoi_quan_ly
--                SET
--                    updated_date = SYSDATE,
--                    ma = p_ma,
--                    ten = p_ten,
--                    dm_bhxh_id = p_dm_bhxh_id,
--                    dm_khoi_kcb_id = p_dm_khoi_kcb_id,
--                    dm_khoi_tk_id = p_dm_khoi_tk_id,
--                    status = p_status,
--                    bhyt = p_bhyt
--            WHERE
--                id = p_id;
--
--            p_output_msg := 'Update success id =' || p_id;
--            IF
--                SQL%rowcount > 0
--            THEN
--                p_output_msg := 'Update success id =' || p_id;
--            ELSE
--                p_output_msg := '0 rows affected. id =' || p_id;
--            END IF;
--
--        ELSE
--            SELECT
--                CASE
--                    WHEN MAX(id) IS NULL THEN 1
--                    ELSE ( MAX(id) + 1 )
--                END
--            INTO
--                id_value
--            FROM
--                common_dm_khoi_quan_ly;
--
--            INSERT INTO common_dm_khoi_quan_ly (
--                id,
--                created_date,
--                updated_date,
--                ma,
--                ten,
--                dm_bhxh_id,
--                dm_khoi_kcb_id,
--                dm_khoi_tk_id,
--                status,
--                bhyt
--            ) VALUES (
--                id_value,
--                SYSDATE,
--                SYSDATE,
--                p_ma,
--                p_ten,
--                p_dm_bhxh_id,
--                p_dm_khoi_kcb_id,
--                p_dm_khoi_tk_id,
--                p_status,
--                p_bhyt
--            );
--
--            p_output_msg := 'Insert success id = ' || id_value;
--        END IF;
--
--        COMMIT;
--        p_output_code := '00';
--    EXCEPTION
--        WHEN OTHERS THEN
--            p_output_code := sqlcode;
--            p_output_msg := substr(
--                sqlerrm,
--                1,
--                2000
--            );
--            INSERT INTO procedure_log (
--                id,
--                error_code,
--                message,
--                id_entity
--            ) VALUES (
--                (
--                    SELECT
--                        MAX(id) + 1
--                    FROM
--                        procedure_log
--                ),
--                p_output_code,
--                p_output_msg,
--                p_id
--            );
--
--            COMMIT;
--    END;
--
--    PROCEDURE sync_cm_dm_khoi_ql (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_khoi_quan_ly WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_khoi_quan_ly_diff
--            );
--
--        INSERT INTO common_dm_khoi_quan_ly (
--            id,
--            created_date,
--            updated_date,
--            ma,
--            ten,
--            dm_bhxh_id,
--            dm_khoi_kcb_id,
--            dm_khoi_tk_id,
--            status,
--            bhyt
--        ) SELECT
--            id,
--            created_date,
--            updated_date,
--            ma,
--            ten,
--            dm_bhxh_id,
--            dm_khoi_kcb_id,
--            dm_khoi_tk_id,
--            status,
--            bhyt
--        FROM
--            common_dm_khoi_quan_ly_diff;
--
--        DELETE common_dm_khoi_quan_ly_diff;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-SYNC_CM_DM_KHOI_QL';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;
--
--    PROCEDURE sync_cm_dm_khoi_ql_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_khoi_quan_ly WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_khoi_quan_ly_diff
--                WHERE
--                    id = p_id
--            );
--
--        INSERT INTO common_dm_khoi_quan_ly (
--            id,
--            created_date,
--            updated_date,
--            ma,
--            ten,
--            dm_bhxh_id,
--            dm_khoi_kcb_id,
--            dm_khoi_tk_id,
--            status,
--            bhyt
--        ) SELECT
--            id,
--            created_date,
--            updated_date,
--            ma,
--            ten,
--            dm_bhxh_id,
--            dm_khoi_kcb_id,
--            dm_khoi_tk_id,
--            status,
--            bhyt
--        FROM
--            common_dm_khoi_quan_ly_diff
--        WHERE
--            id = p_id;
--
--        DELETE common_dm_khoi_quan_ly_diff WHERE
--            id = p_id;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-SYNC_CM_DM_KHOI_QL_ID';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;

    PROCEDURE get_list_cm_dm_khoi_ql_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    ) AS
        p_count        NUMBER(19) := 0;
        p_output_msg   VARCHAR2(2000);
    BEGIN
        SELECT
            COUNT(*)
        INTO
            p_count
        FROM
            common_dm_khoi_quan_ly_diff;

        p_out_total_row := p_count;
        p_out_total_page := floor(p_out_total_row / p_per_page);
        OPEN p_out_table FOR
            SELECT
                *
            FROM
                (
                    SELECT
                        ROW_NUMBER() OVER(
                            ORDER BY verify_id
                        ) AS seqnum,
                        a.verify_id,
                        a.verify_date,
                        a.id,
                        a.updated_date
                    FROM
                        common_dm_khoi_quan_ly_diff a
                    WHERE
                        1 = 1
                ) temp
            WHERE
                    seqnum > ( ( p_page - 1 ) * p_per_page )
                AND
                    seqnum <= ( ( p_page ) * p_per_page );

        IF
            MOD(
                p_out_total_row,
                p_per_page
            ) > 0
        THEN
            p_out_total_page := p_out_total_page + 1;
        END IF;

        p_output_code := '00';
    EXCEPTION
        WHEN OTHERS THEN
            p_output_code := sqlcode;
            p_output_msg := substr(
                sqlerrm,
                1,
                1500
            );
            p_out_table := NULL;
            p_out_total_page := 0;
            p_out_total_row := 0;
            p_output_msg := p_output_msg
             || '-get_list_cm_dm_KHOI_QL_diff-,p_per_page='
             || p_per_page
             || ',p_page='
             || p_page;
            INSERT INTO procedure_log (
                id,
                error_code,
                message,
                id_entity
            ) VALUES (
                (
                    SELECT
                        MAX(id) + 1
                    FROM
                        procedure_log
                ),
                p_output_code,
                p_output_msg,
                0
            );

            COMMIT;
    END;

    PROCEDURE sync_direct_common_dm_khoi_ql (
        p_arr           IN table_cm_dm_khoi_ql,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                INSERT INTO common_dm_khoi_quan_ly (
                    id,
                    created_date,
                    updated_date,
                    ma,
                    ten,
                    dm_bhxh_id,
                    dm_khoi_kcb_id,
                    dm_khoi_tk_id,
                    status,
                    bhyt
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).created_date,
                    p_arr(p_index).updated_date,
                    p_arr(p_index).ma,
                    p_arr(p_index).ten,
                    p_arr(p_index).dm_bhxh_id,
                    p_arr(p_index).dm_khoi_kcb_id,
                    p_arr(p_index).dm_khoi_tk_id,
                    p_arr(p_index).status,
                    p_arr(p_index).bhyt
                );

            END;
        END LOOP;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := 'sync_direct_common_dm_khoi_ql-'
                 || substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

    PROCEDURE del_cm_dm_khoi_ql (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_khoi_quan_ly;

        DELETE common_dm_khoi_quan_ly_diff;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode || '-del_cm_dm_khoi_ql';
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    1
                );

                COMMIT;
            END;
    END;

END pkg_cm_dm_khoi_ql;
/
