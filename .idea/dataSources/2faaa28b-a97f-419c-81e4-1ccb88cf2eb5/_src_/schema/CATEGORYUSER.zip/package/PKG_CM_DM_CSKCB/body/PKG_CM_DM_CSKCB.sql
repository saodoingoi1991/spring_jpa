CREATE PACKAGE BODY "PKG_CM_DM_CSKCB" AS

    PROCEDURE verify_common_dm_cskcb (
        p_arr           IN table_cm_dm_cskcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                DELETE common_dm_cskcb_new WHERE
                    id = p_arr(p_index).id;

                INSERT INTO common_dm_cskcb_new (
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).ten,
                    p_arr(p_index).ma,
                    p_arr(p_index).mabhyt,
                    p_arr(p_index).donvihanhchinh_id,
                    p_arr(p_index).diachi,
                    p_arr(p_index).hangbenhvien,
                    p_arr(p_index).tuyencmkt,
                    p_arr(p_index).hieuluc,
                    p_arr(p_index).mieuta,
                    p_arr(p_index).stt,
                    p_arr(p_index).tinhthanh_id,
                    p_arr(p_index).quanhuyen_id,
                    p_arr(p_index).matinhthanh,
                    p_arr(p_index).maquanhuyen,
                    p_arr(p_index).donvi_id,
                    p_arr(p_index).macosokcbcha,
                    p_arr(p_index).cosokcbcha_id,
                    p_arr(p_index).madonvi,
                    p_arr(p_index).thannhantao,
                    p_arr(p_index).thaighep,
                    p_arr(p_index).loaihopdong,
                    p_arr(p_index).dkkcbbd,
                    p_arr(p_index).hinhthuctt,
                    p_arr(p_index).loaibenhvien,
                    p_arr(p_index).khamtreem,
                    p_arr(p_index).ngayngunghd,
                    p_arr(p_index).mataichinh,
                    p_arr(p_index).pkdakhoa,
                    p_arr(p_index).ungthu,
                    p_arr(p_index).viemgan,
                    p_arr(p_index).tebaomautd,
                    p_arr(p_index).khamt7,
                    p_arr(p_index).khamcn,
                    p_arr(p_index).khamngayle,
                    p_arr(p_index).masothue,
                    p_arr(p_index).dienthoai,
                    p_arr(p_index).email,
                    p_arr(p_index).fax,
                    p_arr(p_index).coquanchuquan,
                    p_arr(p_index).ngaykyhopdong,
                    p_arr(p_index).kieubv,
                    p_arr(p_index).capcskcb_min,
                    p_arr(p_index).ttpheduyet,
                    p_arr(p_index).sohopdong,
                    p_arr(p_index).lydo,
                    p_arr(p_index).trangthai,
                    p_arr(p_index).tuchu,
                    p_arr(p_index).hangdichvu_td,
                    p_arr(p_index).hangthuoc_td,
                    p_arr(p_index).hangvattu_td,
                    p_arr(p_index).byt,
                    p_arr(p_index).so_gphd,
                    p_arr(p_index).kcb,
                    p_arr(p_index).ngaycapma,
                    p_arr(p_index).ngaydieuchinh,
                    p_arr(p_index).loai_donvichuquan,
                    p_arr(p_index).chua_pd43,
                    p_arr(p_index).ngaykyhopdonglandau,
                    p_arr(p_index).ghichu_tinhthaydoi,
                    p_arr(p_index).sl_the_bh_dkbd,
                    p_arr(p_index).sl_the_bh_da_cap,
                    p_arr(p_index).loai_ck
                );

            END;
        END LOOP;
/**
        DELETE common_dm_cskcb_diff WHERE
            id IN (
                SELECT
                    id
                FROM
                    (
                        SELECT
                            id,
                            ten,
                            ma,
                            mabhyt,
                            donvihanhchinh_id,
                            diachi,
                            hangbenhvien,
                            tuyencmkt,
                            hieuluc,
                            mieuta,
                            stt,
                            tinhthanh_id,
                            quanhuyen_id,
                            matinhthanh,
                            maquanhuyen,
                            donvi_id,
                            macosokcbcha,
                            cosokcbcha_id,
                            madonvi,
                            thannhantao,
                            thaighep,
                            loaihopdong,
                            dkkcbbd,
                            hinhthuctt,
                            loaibenhvien,
                            khamtreem,
                            ngayngunghd,
                            mataichinh,
                            pkdakhoa,
                            ungthu,
                            viemgan,
                            tebaomautd,
                            khamt7,
                            khamcn,
                            khamngayle,
                            masothue,
                            dienthoai,
                            email,
                            fax,
                            coquanchuquan,
                            ngaykyhopdong,
                            kieubv,
                            capcskcb_min,
                            ttpheduyet,
                            sohopdong,
                            lydo,
                            trangthai,
                            tuchu,
                            hangdichvu_td,
                            hangthuoc_td,
                            hangvattu_td,
                            byt,
                            so_gphd,
                            kcb,
                            ngaycapma,
                            ngaydieuchinh,
                            loai_donvichuquan,
                            chua_pd43,
                            ngaykyhopdonglandau,
                            ghichu_tinhthaydoi,
                            sl_the_bh_dkbd,
                            sl_the_bh_da_cap,
                            loai_ck
                        FROM
                            common_dm_cskcb_new
                        MINUS
                        SELECT
                            id,
                            ten,
                            ma,
                            mabhyt,
                            donvihanhchinh_id,
                            diachi,
                            hangbenhvien,
                            tuyencmkt,
                            hieuluc,
                            mieuta,
                            stt,
                            tinhthanh_id,
                            quanhuyen_id,
                            matinhthanh,
                            maquanhuyen,
                            donvi_id,
                            macosokcbcha,
                            cosokcbcha_id,
                            madonvi,
                            thannhantao,
                            thaighep,
                            loaihopdong,
                            dkkcbbd,
                            hinhthuctt,
                            loaibenhvien,
                            khamtreem,
                            ngayngunghd,
                            mataichinh,
                            pkdakhoa,
                            ungthu,
                            viemgan,
                            tebaomautd,
                            khamt7,
                            khamcn,
                            khamngayle,
                            masothue,
                            dienthoai,
                            email,
                            fax,
                            coquanchuquan,
                            ngaykyhopdong,
                            kieubv,
                            capcskcb_min,
                            ttpheduyet,
                            sohopdong,
                            lydo,
                            trangthai,
                            tuchu,
                            hangdichvu_td,
                            hangthuoc_td,
                            hangvattu_td,
                            byt,
                            so_gphd,
                            kcb,
                            ngaycapma,
                            ngaydieuchinh,
                            loai_donvichuquan,
                            chua_pd43,
                            ngaykyhopdonglandau,
                            ghichu_tinhthaydoi,
                            sl_the_bh_dkbd,
                            sl_the_bh_da_cap,
                            loai_ck
                        FROM
                            common_dm_cskcb
                    ) diff
            );

        INSERT INTO common_dm_cskcb_diff (
            verify_date,
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        ) SELECT
            SYSDATE,
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        FROM
            (
                SELECT
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                FROM
                    common_dm_cskcb_new
                MINUS
                SELECT
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                FROM
                    common_dm_cskcb
            ) diff;

        DELETE common_dm_cskcb_new;
*/

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                p_output_msg := 'verify_common_dm_cskcb-' || p_output_msg;
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

--    PROCEDURE cud_common_dm_cskcb (
--        p_id                    IN NUMBER,
--        p_ten                   IN NVARCHAR2,
--        p_ma                    IN VARCHAR2,
--        p_mabhyt                IN VARCHAR2,
--        p_donvihanhchinh_id     IN NUMBER,
--        p_diachi                IN VARCHAR2,
--        p_hangbenhvien          IN NUMBER,
--        p_tuyencmkt             IN NUMBER,
--        p_hieuluc               IN NUMBER,
--        p_mieuta                IN NVARCHAR2,
--        p_stt                   IN NUMBER,
--        p_tinhthanh_id          IN NUMBER,
--        p_quanhuyen_id          IN NUMBER,
--        p_matinhthanh           IN VARCHAR2,
--        p_maquanhuyen           IN VARCHAR2,
--        p_donvi_id              IN NUMBER,
--        p_macosokcbcha          IN VARCHAR2,
--        p_cosokcbcha_id         IN NUMBER,
--        p_madonvi               IN VARCHAR2,
--        p_thannhantao           IN NUMBER,
--        p_thaighep              IN NUMBER,
--        p_loaihopdong           IN NUMBER,
--        p_dkkcbbd               IN NUMBER,
--        p_hinhthuctt            IN NUMBER,
--        p_loaibenhvien          IN NUMBER,
--        p_khamtreem             IN NUMBER,
--        p_ngayngunghd           IN VARCHAR2,--date
--        p_mataichinh            IN VARCHAR2,
--        p_pkdakhoa              IN NUMBER,
--        p_ungthu                IN NUMBER,
--        p_viemgan               IN NUMBER,
--        p_tebaomautd            IN NUMBER,
--        p_khamt7                IN NUMBER,
--        p_khamcn                IN NUMBER,
--        p_khamngayle            IN NUMBER,
--        p_masothue              IN VARCHAR2,
--        p_dienthoai             IN VARCHAR2,
--        p_email                 IN VARCHAR2,
--        p_fax                   IN VARCHAR2,
--        p_coquanchuquan         IN VARCHAR2,
--        p_ngaykyhopdong         IN VARCHAR2,--date
--        p_kieubv                IN NUMBER,
--        p_capcskcb_min          IN NUMBER,
--        p_ttpheduyet            IN NUMBER,
--        p_sohopdong             IN NVARCHAR2,
--        p_lydo                  IN NVARCHAR2,
--        p_trangthai             IN NUMBER,
--        p_tuchu                 IN NUMBER,
--        p_hangdichvu_td         IN NUMBER,
--        p_hangthuoc_td          IN NUMBER,
--        p_hangvattu_td          IN NUMBER,
--        p_byt                   IN NUMBER,
--        p_so_gphd               IN NVARCHAR2,
--        p_kcb                   IN NUMBER,
--        p_ngaycapma             IN VARCHAR2,--date
--        p_ngaydieuchinh         IN VARCHAR2,--date
--        p_loai_donvichuquan     IN NUMBER,
--        p_chua_pd43             IN NUMBER,
--        p_ngaykyhopdonglandau   IN VARCHAR2,--date
--        p_ghichu_tinhthaydoi    IN VARCHAR2,
--        p_sl_the_bh_dkbd        IN NUMBER,
--        p_sl_the_bh_da_cap      IN NUMBER,
--        p_loai_ck               IN NUMBER,
--        p_output_code           OUT VARCHAR2,
--        p_output_msg            OUT VARCHAR2
--    ) IS
--        id_value   NUMBER;
--    BEGIN
--        IF
--            p_id IS NOT NULL
--        THEN            
--        --Update 
--            UPDATE common_dm_cskcb
--                SET
--                    ten = p_ten,
--                    ma = p_ma,
--                    mabhyt = p_mabhyt,
--                    donvihanhchinh_id = p_donvihanhchinh_id,
--                    diachi = p_diachi,
--                    hangbenhvien = p_hangbenhvien,
--                    tuyencmkt = p_tuyencmkt,
--                    hieuluc = p_hieuluc,
--                    mieuta = p_mieuta,
--                    stt = p_stt,
--                    tinhthanh_id = p_tinhthanh_id,
--                    quanhuyen_id = p_quanhuyen_id,
--                    matinhthanh = p_matinhthanh,
--                    maquanhuyen = p_maquanhuyen,
--                    donvi_id = p_donvi_id,
--                    macosokcbcha = p_macosokcbcha,
--                    cosokcbcha_id = p_cosokcbcha_id,
--                    madonvi = p_madonvi,
--                    thannhantao = p_thannhantao,
--                    thaighep = p_thaighep,
--                    loaihopdong = p_loaihopdong,
--                    dkkcbbd = p_dkkcbbd,
--                    hinhthuctt = p_hinhthuctt,
--                    loaibenhvien = p_loaibenhvien,
--                    khamtreem = p_khamtreem,
--                    ngayngunghd = TO_DATE(
--                        p_ngayngunghd,
--                        'dd-mm-yyyy HH24:mi:ss'
--                    ),
--                    mataichinh = p_mataichinh,
--                    pkdakhoa = p_pkdakhoa,
--                    ungthu = p_ungthu,
--                    viemgan = p_viemgan,
--                    tebaomautd = p_tebaomautd,
--                    khamt7 = p_khamt7,
--                    khamcn = p_khamcn,
--                    khamngayle = p_khamngayle,
--                    masothue = p_masothue,
--                    dienthoai = p_dienthoai,
--                    email = p_email,
--                    fax = p_fax,
--                    coquanchuquan = p_coquanchuquan,
--                    ngaykyhopdong = TO_DATE(
--                        p_ngaykyhopdong,
--                        'dd-mm-yyyy HH24:mi:ss'
--                    ),
--                    kieubv = p_kieubv,
--                    capcskcb_min = p_capcskcb_min,
--                    ttpheduyet = p_ttpheduyet,
--                    sohopdong = p_sohopdong,
--                    lydo = p_lydo,
--                    trangthai = p_trangthai,
--                    tuchu = p_tuchu,
--                    hangdichvu_td = p_hangdichvu_td,
--                    hangthuoc_td = p_hangthuoc_td,
--                    hangvattu_td = p_hangvattu_td,
--                    byt = p_byt,
--                    so_gphd = p_so_gphd,
--                    kcb = p_kcb,
--                    ngaycapma = TO_DATE(
--                        p_ngaycapma,
--                        'dd-mm-yyyy HH24:mi:ss'
--                    ),
--                    ngaydieuchinh = TO_DATE(
--                        p_ngaydieuchinh,
--                        'dd-mm-yyyy HH24:mi:ss'
--                    ),
--                    loai_donvichuquan = p_loai_donvichuquan,
--                    chua_pd43 = p_chua_pd43,
--                    ngaykyhopdonglandau = TO_DATE(
--                        p_ngaykyhopdonglandau,
--                        'dd-mm-yyyy HH24:mi:ss'
--                    ),
--                    ghichu_tinhthaydoi = p_ghichu_tinhthaydoi,
--                    sl_the_bh_dkbd = p_sl_the_bh_dkbd,
--                    sl_the_bh_da_cap = p_sl_the_bh_da_cap,
--                    loai_ck = p_loai_ck
--            WHERE
--                id = p_id;
--
----        p_output_msg := 'Update success id =' || p_id;
--
--            IF
--                SQL%rowcount > 0
--            THEN
--                p_output_msg := 'Update success id =' || p_id;
--            ELSE
--                p_output_msg := '0 rows affected. id =' || p_id;
--            END IF;
--
--        ELSE
--            SELECT
--                CASE
--                    WHEN MAX(id) IS NULL THEN 1
--                    ELSE ( MAX(id) + 1 )
--                END
--            INTO
--                id_value
--            FROM
--                common_dm_cskcb;
--         --Insert          
--
--            INSERT INTO common_dm_cskcb (
--                id,
--                ten,
--                ma,
--                mabhyt,
--                donvihanhchinh_id,
--                diachi,
--                hangbenhvien,
--                tuyencmkt,
--                hieuluc,
--                mieuta,
--                stt,
--                tinhthanh_id,
--                quanhuyen_id,
--                matinhthanh,
--                maquanhuyen,
--                donvi_id,
--                macosokcbcha,
--                cosokcbcha_id,
--                madonvi,
--                thannhantao,
--                thaighep,
--                loaihopdong,
--                dkkcbbd,
--                hinhthuctt,
--                loaibenhvien,
--                khamtreem,
--                ngayngunghd,
--                mataichinh,
--                pkdakhoa,
--                ungthu,
--                viemgan,
--                tebaomautd,
--                khamt7,
--                khamcn,
--                khamngayle,
--                masothue,
--                dienthoai,
--                email,
--                fax,
--                coquanchuquan,
--                ngaykyhopdong,
--                kieubv,
--                capcskcb_min,
--                ttpheduyet,
--                sohopdong,
--                lydo,
--                trangthai,
--                tuchu,
--                hangdichvu_td,
--                hangthuoc_td,
--                hangvattu_td,
--                byt,
--                so_gphd,
--                kcb,
--                ngaycapma,
--                ngaydieuchinh,
--                loai_donvichuquan,
--                chua_pd43,
--                ngaykyhopdonglandau,
--                ghichu_tinhthaydoi,
--                sl_the_bh_dkbd,
--                sl_the_bh_da_cap,
--                loai_ck
--            ) VALUES (
--                id_value,
--                p_ten,
--                p_ma,
--                p_mabhyt,
--                p_donvihanhchinh_id,
--                p_diachi,
--                p_hangbenhvien,
--                p_tuyencmkt,
--                p_hieuluc,
--                p_mieuta,
--                p_stt,
--                p_tinhthanh_id,
--                p_quanhuyen_id,
--                p_matinhthanh,
--                p_maquanhuyen,
--                p_donvi_id,
--                p_macosokcbcha,
--                p_cosokcbcha_id,
--                p_madonvi,
--                p_thannhantao,
--                p_thaighep,
--                p_loaihopdong,
--                p_dkkcbbd,
--                p_hinhthuctt,
--                p_loaibenhvien,
--                p_khamtreem,
--                TO_DATE(
--                    p_ngayngunghd,
--                    'dd-mm-yyyy HH24:mi:ss'
--                ),
--                p_mataichinh,
--                p_pkdakhoa,
--                p_ungthu,
--                p_viemgan,
--                p_tebaomautd,
--                p_khamt7,
--                p_khamcn,
--                p_khamngayle,
--                p_masothue,
--                p_dienthoai,
--                p_email,
--                p_fax,
--                p_coquanchuquan,
--                TO_DATE(
--                    p_ngaykyhopdong,
--                    'dd-mm-yyyy HH24:mi:ss'
--                ),
--                p_kieubv,
--                p_capcskcb_min,
--                p_ttpheduyet,
--                p_sohopdong,
--                p_lydo,
--                p_trangthai,
--                p_tuchu,
--                p_hangdichvu_td,
--                p_hangthuoc_td,
--                p_hangvattu_td,
--                p_byt,
--                p_so_gphd,
--                p_kcb,
--                TO_DATE(
--                    p_ngaycapma,
--                    'dd-mm-yyyy HH24:mi:ss'
--                ),
--                TO_DATE(
--                    p_ngaydieuchinh,
--                    'dd-mm-yyyy HH24:mi:ss'
--                ),
--                p_loai_donvichuquan,
--                p_chua_pd43,
--                TO_DATE(
--                    p_ngaykyhopdonglandau,
--                    'dd-mm-yyyy HH24:mi:ss'
--                ),
--                p_ghichu_tinhthaydoi,
--                p_sl_the_bh_dkbd,
--                p_sl_the_bh_da_cap,
--                p_loai_ck
--            );
--
--            p_output_msg := 'Insert success id =' || id_value;
--        END IF;
--
--        COMMIT;
--        p_output_code := '00';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                p_output_code := sqlcode;
--                p_output_msg := 'cud_common_dm_cskcb-'
--                 || substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    p_id
--                );
--
--                COMMIT;
--            END;
--    END;

--    PROCEDURE sync_cm_dm_cskcb (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_cskcb WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_cskcb_diff
--            );
--
--        INSERT INTO common_dm_cskcb (
--            id,
--            ten,
--            ma,
--            mabhyt,
--            donvihanhchinh_id,
--            diachi,
--            hangbenhvien,
--            tuyencmkt,
--            hieuluc,
--            mieuta,
--            stt,
--            tinhthanh_id,
--            quanhuyen_id,
--            matinhthanh,
--            maquanhuyen,
--            donvi_id,
--            macosokcbcha,
--            cosokcbcha_id,
--            madonvi,
--            thannhantao,
--            thaighep,
--            loaihopdong,
--            dkkcbbd,
--            hinhthuctt,
--            loaibenhvien,
--            khamtreem,
--            ngayngunghd,
--            mataichinh,
--            pkdakhoa,
--            ungthu,
--            viemgan,
--            tebaomautd,
--            khamt7,
--            khamcn,
--            khamngayle,
--            masothue,
--            dienthoai,
--            email,
--            fax,
--            coquanchuquan,
--            ngaykyhopdong,
--            kieubv,
--            capcskcb_min,
--            ttpheduyet,
--            sohopdong,
--            lydo,
--            trangthai,
--            tuchu,
--            hangdichvu_td,
--            hangthuoc_td,
--            hangvattu_td,
--            byt,
--            so_gphd,
--            kcb,
--            ngaycapma,
--            ngaydieuchinh,
--            loai_donvichuquan,
--            chua_pd43,
--            ngaykyhopdonglandau,
--            ghichu_tinhthaydoi,
--            sl_the_bh_dkbd,
--            sl_the_bh_da_cap,
--            loai_ck
--        ) SELECT
--            id,
--            ten,
--            ma,
--            mabhyt,
--            donvihanhchinh_id,
--            diachi,
--            hangbenhvien,
--            tuyencmkt,
--            hieuluc,
--            mieuta,
--            stt,
--            tinhthanh_id,
--            quanhuyen_id,
--            matinhthanh,
--            maquanhuyen,
--            donvi_id,
--            macosokcbcha,
--            cosokcbcha_id,
--            madonvi,
--            thannhantao,
--            thaighep,
--            loaihopdong,
--            dkkcbbd,
--            hinhthuctt,
--            loaibenhvien,
--            khamtreem,
--            ngayngunghd,
--            mataichinh,
--            pkdakhoa,
--            ungthu,
--            viemgan,
--            tebaomautd,
--            khamt7,
--            khamcn,
--            khamngayle,
--            masothue,
--            dienthoai,
--            email,
--            fax,
--            coquanchuquan,
--            ngaykyhopdong,
--            kieubv,
--            capcskcb_min,
--            ttpheduyet,
--            sohopdong,
--            lydo,
--            trangthai,
--            tuchu,
--            hangdichvu_td,
--            hangthuoc_td,
--            hangvattu_td,
--            byt,
--            so_gphd,
--            kcb,
--            ngaycapma,
--            ngaydieuchinh,
--            loai_donvichuquan,
--            chua_pd43,
--            ngaykyhopdonglandau,
--            ghichu_tinhthaydoi,
--            sl_the_bh_dkbd,
--            sl_the_bh_da_cap,
--            loai_ck
--        FROM
--            common_dm_cskcb_diff;
--
--        DELETE common_dm_cskcb_diff;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode;
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                p_output_msg := 'SYNC_CM_DM_CSKCB - ' || p_output_msg;
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;
--
--    PROCEDURE sync_cm_dm_cskcb_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_cskcb WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_cskcb_diff
--                WHERE
--                    id = p_id
--            );
--
--        INSERT INTO common_dm_cskcb (
--            id,
--            ten,
--            ma,
--            mabhyt,
--            donvihanhchinh_id,
--            diachi,
--            hangbenhvien,
--            tuyencmkt,
--            hieuluc,
--            mieuta,
--            stt,
--            tinhthanh_id,
--            quanhuyen_id,
--            matinhthanh,
--            maquanhuyen,
--            donvi_id,
--            macosokcbcha,
--            cosokcbcha_id,
--            madonvi,
--            thannhantao,
--            thaighep,
--            loaihopdong,
--            dkkcbbd,
--            hinhthuctt,
--            loaibenhvien,
--            khamtreem,
--            ngayngunghd,
--            mataichinh,
--            pkdakhoa,
--            ungthu,
--            viemgan,
--            tebaomautd,
--            khamt7,
--            khamcn,
--            khamngayle,
--            masothue,
--            dienthoai,
--            email,
--            fax,
--            coquanchuquan,
--            ngaykyhopdong,
--            kieubv,
--            capcskcb_min,
--            ttpheduyet,
--            sohopdong,
--            lydo,
--            trangthai,
--            tuchu,
--            hangdichvu_td,
--            hangthuoc_td,
--            hangvattu_td,
--            byt,
--            so_gphd,
--            kcb,
--            ngaycapma,
--            ngaydieuchinh,
--            loai_donvichuquan,
--            chua_pd43,
--            ngaykyhopdonglandau,
--            ghichu_tinhthaydoi,
--            sl_the_bh_dkbd,
--            sl_the_bh_da_cap,
--            loai_ck
--        ) SELECT
--            id,
--            ten,
--            ma,
--            mabhyt,
--            donvihanhchinh_id,
--            diachi,
--            hangbenhvien,
--            tuyencmkt,
--            hieuluc,
--            mieuta,
--            stt,
--            tinhthanh_id,
--            quanhuyen_id,
--            matinhthanh,
--            maquanhuyen,
--            donvi_id,
--            macosokcbcha,
--            cosokcbcha_id,
--            madonvi,
--            thannhantao,
--            thaighep,
--            loaihopdong,
--            dkkcbbd,
--            hinhthuctt,
--            loaibenhvien,
--            khamtreem,
--            ngayngunghd,
--            mataichinh,
--            pkdakhoa,
--            ungthu,
--            viemgan,
--            tebaomautd,
--            khamt7,
--            khamcn,
--            khamngayle,
--            masothue,
--            dienthoai,
--            email,
--            fax,
--            coquanchuquan,
--            ngaykyhopdong,
--            kieubv,
--            capcskcb_min,
--            ttpheduyet,
--            sohopdong,
--            lydo,
--            trangthai,
--            tuchu,
--            hangdichvu_td,
--            hangthuoc_td,
--            hangvattu_td,
--            byt,
--            so_gphd,
--            kcb,
--            ngaycapma,
--            ngaydieuchinh,
--            loai_donvichuquan,
--            chua_pd43,
--            ngaykyhopdonglandau,
--            ghichu_tinhthaydoi,
--            sl_the_bh_dkbd,
--            sl_the_bh_da_cap,
--            loai_ck
--        FROM
--            common_dm_cskcb_diff
--        WHERE
--            id = p_id;
--
--        DELETE common_dm_cskcb_diff WHERE
--            id = p_id;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-SYNC_CM_DM_CSKCB_ID';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;

    PROCEDURE get_list_cm_dm_cskcb_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    ) AS
        p_count        NUMBER(19) := 0;
        p_output_msg   VARCHAR2(2000);
    BEGIN
        SELECT
            COUNT(*)
        INTO
            p_count
        FROM
            common_dm_cskcb_diff;

        p_out_total_row := p_count;
        p_out_total_page := floor(p_out_total_row / p_per_page);
        OPEN p_out_table FOR
            SELECT
                *
            FROM
                (
                    SELECT
                        ROW_NUMBER() OVER(
                            ORDER BY verify_id
                        ) AS seqnum,
                        a.verify_id,
                        a.verify_date,
                        a.id
                    FROM
                        common_dm_cskcb_diff a
                    WHERE
                        1 = 1
                ) temp
            WHERE
                    seqnum > ( ( p_page - 1 ) * p_per_page )
                AND
                    seqnum <= ( ( p_page ) * p_per_page );

        IF
            MOD(
                p_out_total_row,
                p_per_page
            ) > 0
        THEN
            p_out_total_page := p_out_total_page + 1;
        END IF;

        p_output_code := '00';
    EXCEPTION
        WHEN OTHERS THEN
            p_output_code := sqlcode;
            p_output_msg := 'GET_LIST_CM_DM_CSKCB_DIFF'
             || substr(
                sqlerrm,
                1,
                1500
            );
            p_out_table := NULL;
            p_out_total_page := 0;
            p_out_total_row := 0;
            p_output_msg := p_output_msg
             || ',p_per_page='
             || p_per_page
             || ',p_page='
             || p_page;
            INSERT INTO procedure_log (
                id,
                error_code,
                message,
                id_entity
            ) VALUES (
                (
                    SELECT
                        MAX(id) + 1
                    FROM
                        procedure_log
                ),
                p_output_code,
                p_output_msg,
                0
            );

            COMMIT;
    END;

    PROCEDURE del_cm_dm_cskcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_cskcb;

        DELETE common_dm_cskcb_diff;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                p_output_msg := 'del_cm_dm_cskcb - ' || p_output_msg;
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    1
                );

                COMMIT;
            END;
    END;

    PROCEDURE sync_direct_common_dm_cskcb (
        p_arr           IN table_cm_dm_cskcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                INSERT INTO common_dm_cskcb (
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).ten,
                    p_arr(p_index).ma,
                    p_arr(p_index).mabhyt,
                    p_arr(p_index).donvihanhchinh_id,
                    p_arr(p_index).diachi,
                    p_arr(p_index).hangbenhvien,
                    p_arr(p_index).tuyencmkt,
                    p_arr(p_index).hieuluc,
                    p_arr(p_index).mieuta,
                    p_arr(p_index).stt,
                    p_arr(p_index).tinhthanh_id,
                    p_arr(p_index).quanhuyen_id,
                    p_arr(p_index).matinhthanh,
                    p_arr(p_index).maquanhuyen,
                    p_arr(p_index).donvi_id,
                    p_arr(p_index).macosokcbcha,
                    p_arr(p_index).cosokcbcha_id,
                    p_arr(p_index).madonvi,
                    p_arr(p_index).thannhantao,
                    p_arr(p_index).thaighep,
                    p_arr(p_index).loaihopdong,
                    p_arr(p_index).dkkcbbd,
                    p_arr(p_index).hinhthuctt,
                    p_arr(p_index).loaibenhvien,
                    p_arr(p_index).khamtreem,
                    p_arr(p_index).ngayngunghd,
                    p_arr(p_index).mataichinh,
                    p_arr(p_index).pkdakhoa,
                    p_arr(p_index).ungthu,
                    p_arr(p_index).viemgan,
                    p_arr(p_index).tebaomautd,
                    p_arr(p_index).khamt7,
                    p_arr(p_index).khamcn,
                    p_arr(p_index).khamngayle,
                    p_arr(p_index).masothue,
                    p_arr(p_index).dienthoai,
                    p_arr(p_index).email,
                    p_arr(p_index).fax,
                    p_arr(p_index).coquanchuquan,
                    p_arr(p_index).ngaykyhopdong,
                    p_arr(p_index).kieubv,
                    p_arr(p_index).capcskcb_min,
                    p_arr(p_index).ttpheduyet,
                    p_arr(p_index).sohopdong,
                    p_arr(p_index).lydo,
                    p_arr(p_index).trangthai,
                    p_arr(p_index).tuchu,
                    p_arr(p_index).hangdichvu_td,
                    p_arr(p_index).hangthuoc_td,
                    p_arr(p_index).hangvattu_td,
                    p_arr(p_index).byt,
                    p_arr(p_index).so_gphd,
                    p_arr(p_index).kcb,
                    p_arr(p_index).ngaycapma,
                    p_arr(p_index).ngaydieuchinh,
                    p_arr(p_index).loai_donvichuquan,
                    p_arr(p_index).chua_pd43,
                    p_arr(p_index).ngaykyhopdonglandau,
                    p_arr(p_index).ghichu_tinhthaydoi,
                    p_arr(p_index).sl_the_bh_dkbd,
                    p_arr(p_index).sl_the_bh_da_cap,
                    p_arr(p_index).loai_ck
                );

            END;
        END LOOP;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                p_output_msg := 'sync_direct_common_dm_cskcb-' || p_output_msg;
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

    PROCEDURE exec_verify_common_dm_cskcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_cskcb_diff;

        INSERT INTO common_dm_cskcb_diff (
            verify_date,
            verify_type,
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        ) SELECT
            SYSDATE,
            2,
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        FROM
            (
                SELECT
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                FROM
                    common_dm_cskcb_new
                MINUS
                SELECT
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                FROM
                    common_dm_cskcb
            ) diff;

        INSERT INTO common_dm_cskcb_diff (
            verify_date,
            verify_type,
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        ) SELECT
            SYSDATE,
            1,
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        FROM
            (
                SELECT
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                FROM
                    common_dm_cskcb
                MINUS
                SELECT
                    id,
                    ten,
                    ma,
                    mabhyt,
                    donvihanhchinh_id,
                    diachi,
                    hangbenhvien,
                    tuyencmkt,
                    hieuluc,
                    mieuta,
                    stt,
                    tinhthanh_id,
                    quanhuyen_id,
                    matinhthanh,
                    maquanhuyen,
                    donvi_id,
                    macosokcbcha,
                    cosokcbcha_id,
                    madonvi,
                    thannhantao,
                    thaighep,
                    loaihopdong,
                    dkkcbbd,
                    hinhthuctt,
                    loaibenhvien,
                    khamtreem,
                    ngayngunghd,
                    mataichinh,
                    pkdakhoa,
                    ungthu,
                    viemgan,
                    tebaomautd,
                    khamt7,
                    khamcn,
                    khamngayle,
                    masothue,
                    dienthoai,
                    email,
                    fax,
                    coquanchuquan,
                    ngaykyhopdong,
                    kieubv,
                    capcskcb_min,
                    ttpheduyet,
                    sohopdong,
                    lydo,
                    trangthai,
                    tuchu,
                    hangdichvu_td,
                    hangthuoc_td,
                    hangvattu_td,
                    byt,
                    so_gphd,
                    kcb,
                    ngaycapma,
                    ngaydieuchinh,
                    loai_donvichuquan,
                    chua_pd43,
                    ngaykyhopdonglandau,
                    ghichu_tinhthaydoi,
                    sl_the_bh_dkbd,
                    sl_the_bh_da_cap,
                    loai_ck
                FROM
                    common_dm_cskcb_new
            ) diff;

        DELETE common_dm_cskcb_new;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode;
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                p_output_msg := 'verify_all_common_dm_cskcb-' || p_output_msg;
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    0
                );

                COMMIT;
            END;
    END;

END pkg_cm_dm_cskcb;
/
