CREATE PACKAGE                "PKG_CM_DM_NGHIEP_VU" AS
    PROCEDURE verify_common_dm_nghiep_vu (
        p_arr           IN table_cm_dm_nghiep_vu,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

	PROCEDURE exec_verify_cm_dm_nghiep_vu (        
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

--    PROCEDURE cud_common_dm_nghiep_vu (
--        p_id            IN NUMBER,
--        p_bhxh          IN NUMBER,
--        p_bhyt          IN NUMBER,
--        p_grp1          IN NUMBER,
--        p_grp2          IN NUMBER,
--        p_ma            IN VARCHAR2,
--        p_qt            IN NUMBER,
--        p_ten           IN VARCHAR2,
--        p_tg            IN NUMBER,
--        p_trang_thai    IN NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );

--    PROCEDURE sync_cm_dm_nghiep_vu (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );
--
--    PROCEDURE sync_cm_dm_nghiep_vu_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );

    PROCEDURE get_list_cm_dm_nghiep_vu_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    );

    PROCEDURE sync_direct_cm_dm_nghiep_vu (
        p_arr           IN table_cm_dm_nghiep_vu,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

    PROCEDURE del_cm_dm_nghiep_vu (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

END pkg_cm_dm_nghiep_vu;
/
