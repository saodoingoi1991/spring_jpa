CREATE PACKAGE                "PKG_CM_DM_CSKCB" AS
    PROCEDURE verify_common_dm_cskcb (
        p_arr           IN table_cm_dm_cskcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

--    PROCEDURE cud_common_dm_cskcb (
--        p_id                    IN NUMBER,
--        p_ten                   IN NVARCHAR2,
--        p_ma                    IN VARCHAR2,
--        p_mabhyt                IN VARCHAR2,
--        p_donvihanhchinh_id     IN NUMBER,
--        p_diachi                IN VARCHAR2,
--        p_hangbenhvien          IN NUMBER,
--        p_tuyencmkt             IN NUMBER,
--        p_hieuluc               IN NUMBER,
--        p_mieuta                IN NVARCHAR2,
--        p_stt                   IN NUMBER,
--        p_tinhthanh_id          IN NUMBER,
--        p_quanhuyen_id          IN NUMBER,
--        p_matinhthanh           IN VARCHAR2,
--        p_maquanhuyen           IN VARCHAR2,
--        p_donvi_id              IN NUMBER,
--        p_macosokcbcha          IN VARCHAR2,
--        p_cosokcbcha_id         IN NUMBER,
--        p_madonvi               IN VARCHAR2,
--        p_thannhantao           IN NUMBER,
--        p_thaighep              IN NUMBER,
--        p_loaihopdong           IN NUMBER,
--        p_dkkcbbd               IN NUMBER,
--        p_hinhthuctt            IN NUMBER,
--        p_loaibenhvien          IN NUMBER,
--        p_khamtreem             IN NUMBER,
--        p_ngayngunghd           IN VARCHAR2,--date
--        p_mataichinh            IN VARCHAR2,
--        p_pkdakhoa              IN NUMBER,
--        p_ungthu                IN NUMBER,
--        p_viemgan               IN NUMBER,
--        p_tebaomautd            IN NUMBER,
--        p_khamt7                IN NUMBER,
--        p_khamcn                IN NUMBER,
--        p_khamngayle            IN NUMBER,
--        p_masothue              IN VARCHAR2,
--        p_dienthoai             IN VARCHAR2,
--        p_email                 IN VARCHAR2,
--        p_fax                   IN VARCHAR2,
--        p_coquanchuquan         IN VARCHAR2,
--        p_ngaykyhopdong         IN VARCHAR2,--date
--        p_kieubv                IN NUMBER,
--        p_capcskcb_min          IN NUMBER,
--        p_ttpheduyet            IN NUMBER,
--        p_sohopdong             IN NVARCHAR2,
--        p_lydo                  IN NVARCHAR2,
--        p_trangthai             IN NUMBER,
--        p_tuchu                 IN NUMBER,
--        p_hangdichvu_td         IN NUMBER,
--        p_hangthuoc_td          IN NUMBER,
--        p_hangvattu_td          IN NUMBER,
--        p_byt                   IN NUMBER,
--        p_so_gphd               IN NVARCHAR2,
--        p_kcb                   IN NUMBER,
--        p_ngaycapma             IN VARCHAR2,--date
--        p_ngaydieuchinh         IN VARCHAR2,--date
--        p_loai_donvichuquan     IN NUMBER,
--        p_chua_pd43             IN NUMBER,
--        p_ngaykyhopdonglandau   IN VARCHAR2,--date
--        p_ghichu_tinhthaydoi    IN VARCHAR2,
--        p_sl_the_bh_dkbd        IN NUMBER,
--        p_sl_the_bh_da_cap      IN NUMBER,
--        p_loai_ck               IN NUMBER,
--        p_output_code           OUT VARCHAR2,
--        p_output_msg            OUT VARCHAR2
--    );

--    PROCEDURE sync_cm_dm_cskcb (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );
--
--    PROCEDURE sync_cm_dm_cskcb_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    );

    PROCEDURE get_list_cm_dm_cskcb_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    );

    PROCEDURE del_cm_dm_cskcb (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

    PROCEDURE sync_direct_common_dm_cskcb (
        p_arr     IN table_cm_dm_cskcb,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

    PROCEDURE exec_verify_common_dm_cskcb (        
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    );

END pkg_cm_dm_cskcb;
/
