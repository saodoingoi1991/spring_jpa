CREATE PACKAGE BODY "PKG_CM_DM_NGHIEP_VU" AS

    PROCEDURE verify_common_dm_nghiep_vu (
        p_arr           IN table_cm_dm_nghiep_vu,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                DELETE common_dm_nghiep_vu_new WHERE
                    id = p_arr(p_index).id;

                INSERT INTO common_dm_nghiep_vu_new (
                    id,
                    bhxh,
                    bhyt,
                    grp1,
                    grp2,
                    ma,
                    qt,
                    ten,
                    tg,
                    trang_thai
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).bhxh,
                    p_arr(p_index).bhyt,
                    p_arr(p_index).grp1,
                    p_arr(p_index).grp2,
                    p_arr(p_index).ma,
                    p_arr(p_index).qt,
                    p_arr(p_index).ten,
                    p_arr(p_index).tg,
                    p_arr(p_index).trang_thai
                );

            END;
        END LOOP;

--        DELETE common_dm_nghiep_vu_diff WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    (
--                        SELECT
--                            id,
--                            bhxh,
--                            bhyt,
--                            grp1,
--                            grp2,
--                            ma,
--                            qt,
--                            ten,
--                            tg,
--                            trang_thai
--                        FROM
--                            common_dm_nghiep_vu_new
--                        MINUS
--                        SELECT
--                            id,
--                            bhxh,
--                            bhyt,
--                            grp1,
--                            grp2,
--                            ma,
--                            qt,
--                            ten,
--                            tg,
--                            trang_thai
--                        FROM
--                            common_dm_nghiep_vu
--                    ) diff
--            );
--
--        INSERT INTO common_dm_nghiep_vu_diff (
--            verify_date,
--            id,
--            bhxh,
--            bhyt,
--            grp1,
--            grp2,
--            ma,
--            qt,
--            ten,
--            tg,
--            trang_thai
--        ) SELECT
--            SYSDATE,
--            id,
--            bhxh,
--            bhyt,
--            grp1,
--            grp2,
--            ma,
--            qt,
--            ten,
--            tg,
--            trang_thai
--        FROM
--            (
--                SELECT
--                    id,
--                    bhxh,
--                    bhyt,
--                    grp1,
--                    grp2,
--                    ma,
--                    qt,
--                    ten,
--                    tg,
--                    trang_thai
--                FROM
--                    common_dm_nghiep_vu_new
--                MINUS
--                SELECT
--                    id,
--                    bhxh,
--                    bhyt,
--                    grp1,
--                    grp2,
--                    ma,
--                    qt,
--                    ten,
--                    tg,
--                    trang_thai
--                FROM
--                    common_dm_nghiep_vu
--            ) diff;
--
--        DELETE common_dm_nghiep_vu_new;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode
                 || '-VERIFY_COMMON_DM_NGHIEP_VU-'
                 || p_arr(p_index).id
                 || '-'
                 || p_index;

                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

	--exec

    PROCEDURE exec_verify_cm_dm_nghiep_vu (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_nghiep_vu_diff;

        INSERT INTO common_dm_nghiep_vu_diff (
            verify_date,
            verify_type,
            id,
            bhxh,
            bhyt,
            grp1,
            grp2,
            ma,
            qt,
            ten,
            tg,
            trang_thai
        ) SELECT
            SYSDATE,
            2,
            id,
            bhxh,
            bhyt,
            grp1,
            grp2,
            ma,
            qt,
            ten,
            tg,
            trang_thai
        FROM
            (
                SELECT
                    id,
                    bhxh,
                    bhyt,
                    grp1,
                    grp2,
                    ma,
                    qt,
                    ten,
                    tg,
                    trang_thai
                FROM
                    common_dm_nghiep_vu_new
                MINUS
                SELECT
                    id,
                    bhxh,
                    bhyt,
                    grp1,
                    grp2,
                    ma,
                    qt,
                    ten,
                    tg,
                    trang_thai
                FROM
                    common_dm_nghiep_vu
            ) diff;

        INSERT INTO common_dm_nghiep_vu_diff (
            verify_date,
            verify_type,
            id,
            bhxh,
            bhyt,
            grp1,
            grp2,
            ma,
            qt,
            ten,
            tg,
            trang_thai
        ) SELECT
            SYSDATE,
            1,
            id,
            bhxh,
            bhyt,
            grp1,
            grp2,
            ma,
            qt,
            ten,
            tg,
            trang_thai
        FROM
            (
                SELECT
                    id,
                    bhxh,
                    bhyt,
                    grp1,
                    grp2,
                    ma,
                    qt,
                    ten,
                    tg,
                    trang_thai
                FROM
                    common_dm_nghiep_vu
                MINUS
                SELECT
                    id,
                    bhxh,
                    bhyt,
                    grp1,
                    grp2,
                    ma,
                    qt,
                    ten,
                    tg,
                    trang_thai
                FROM
                    common_dm_nghiep_vu_new
            ) diff;

        DELETE common_dm_nghiep_vu_new;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode || '-exec_verify_cm_dm_nghiep_vu-';
                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    0
                );

                COMMIT;
            END;
    END;

--    PROCEDURE cud_common_dm_nghiep_vu  (
--        p_id            IN NUMBER,
--        p_bhxh          IN NUMBER,
--        p_bhyt          IN NUMBER,
--        p_grp1          IN NUMBER,
--        p_grp2          IN NUMBER,
--        p_ma            IN VARCHAR2,
--        p_qt            IN NUMBER,
--        p_ten           IN VARCHAR2,
--        p_tg            IN NUMBER,
--        p_trang_thai    IN NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    ) IS
--        id_value   NUMBER;
--    BEGIN
--        IF
--            p_id IS NOT NULL
--        THEN
--    --update
--            UPDATE common_dm_nghiep_vu
--                SET
--                    bhxh = p_bhxh,
--                    bhyt = p_bhyt,
--                    grp1 = p_grp1,
--                    grp2 = p_grp2,
--                    ma = p_ma,
--                    qt = p_qt,
--                    ten = p_ten,
--                    tg = p_tg,
--                    trang_thai = p_trang_thai
--            WHERE
--                id = p_id;
--
----        p_output_msg := 'Update success id =' || p_id;
--
--            IF
--                SQL%rowcount > 0
--            THEN
--                p_output_msg := 'Update success id =' || p_id;
--            ELSE
--                p_output_msg := '0 rows affected. id =' || p_id;
--            END IF;
--
--        ELSE
--    --insert
--            SELECT
--                CASE
--                    WHEN MAX(id) IS NULL THEN 1
--                    ELSE ( MAX(id) + 1 )
--                END
--            INTO
--                id_value
--            FROM
--                common_dm_nghiep_vu;
--
--            INSERT INTO common_dm_nghiep_vu (
--                id,
--                bhxh,
--                bhyt,
--                grp1,
--                grp2,
--                ma,
--                qt,
--                ten,
--                tg,
--                trang_thai
--            ) VALUES (
--                id_value,
--                p_bhxh,
--                p_bhyt,
--                p_grp1,
--                p_grp2,
--                p_ma,
--                p_qt,
--                p_ten,
--                p_tg,
--                p_trang_thai
--            );
--
--            p_output_msg := 'Insert success id=' || id_value;
--        END IF;
--
--        COMMIT;
--        p_output_code := '00';
--    EXCEPTION
--        WHEN OTHERS THEN
--            p_output_code := sqlcode;
--            p_output_msg := substr(
--                sqlerrm,
--                1,
--                2000
--            );
--            INSERT INTO procedure_log (
--                id,
--                error_code,
--                message,
--                id_entity
--            ) VALUES (
--                (
--                    SELECT
--                        MAX(id) + 1
--                    FROM
--                        procedure_log
--                ),
--                p_output_code,
--                p_output_msg,
--                p_id
--            );
--
--            COMMIT;
--    END;
--
--    PROCEDURE sync_cm_dm_nghiep_vu (
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_nghiep_vu WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_nghiep_vu_diff
--            );
--
--        INSERT INTO common_dm_nghiep_vu (
--            id,
--            bhxh,
--            bhyt,
--            grp1,
--            grp2,
--            ma,
--            qt,
--            ten,
--            tg,
--            trang_thai
--        ) SELECT
--            id,
--            bhxh,
--            bhyt,
--            grp1,
--            grp2,
--            ma,
--            qt,
--            ten,
--            tg,
--            trang_thai
--        FROM
--            common_dm_nghiep_vu_diff;
--
--        DELETE common_dm_nghiep_vu_diff;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            ROLLBACK;
--            p_output_code := sqlcode || '-SYNC_CM_DM_NGHIEP_VU';
--            p_output_msg := substr(
--                sqlerrm,
--                1,
--                2000
--            );
--            INSERT INTO procedure_log (
--                id,
--                error_code,
--                message,
--                id_entity
--            ) VALUES (
--                (
--                    SELECT
--                        MAX(id) + 1
--                    FROM
--                        procedure_log
--                ),
--                p_output_code,
--                p_output_msg,
--                1
--            );
--
--            COMMIT;
--    END;
--
--    PROCEDURE sync_cm_dm_nghiep_vu_id (
--        p_id            NUMBER,
--        p_output_code   OUT VARCHAR2,
--        p_output_msg    OUT VARCHAR2
--    )
--        AS
--    BEGIN
--        DELETE common_dm_nghiep_vu WHERE
--            id IN (
--                SELECT
--                    id
--                FROM
--                    common_dm_nghiep_vu_diff
--                WHERE
--                    id = p_id
--            );
--
--        INSERT INTO common_dm_nghiep_vu (
--            id,
--            bhxh,
--            bhyt,
--            grp1,
--            grp2,
--            ma,
--            qt,
--            ten,
--            tg,
--            trang_thai
--        ) SELECT
--            id,
--            bhxh,
--            bhyt,
--            grp1,
--            grp2,
--            ma,
--            qt,
--            ten,
--            tg,
--            trang_thai
--        FROM
--            common_dm_nghiep_vu_diff
--        WHERE
--            id = p_id;
--
--        DELETE common_dm_nghiep_vu_diff WHERE
--            id = p_id;
--
--        COMMIT;
--        p_output_code := '00';
--        p_output_msg := 'Success';
--    EXCEPTION
--        WHEN OTHERS THEN
--            BEGIN
--                ROLLBACK;
--                p_output_code := sqlcode || '-SYNC_CM_DM_NGHIEP_VU_ID';
--                p_output_msg := substr(
--                    sqlerrm,
--                    1,
--                    2000
--                );
--                INSERT INTO procedure_log (
--                    id,
--                    error_code,
--                    message,
--                    id_entity
--                ) VALUES (
--                    (
--                        SELECT
--                            MAX(id) + 1
--                        FROM
--                            procedure_log
--                    ),
--                    p_output_code,
--                    p_output_msg,
--                    1
--                );
--
--                COMMIT;
--            END;
--    END;

    PROCEDURE get_list_cm_dm_nghiep_vu_diff (
        p_per_page         IN NUMBER,-- SO ROW TREN 1 TRANG (PHAN TRANG)
        p_page             IN NUMBER,-- SO TRANG   
        p_out_total_page   OUT NUMBER,
        p_out_total_row    OUT NUMBER,
        p_output_code      OUT VARCHAR2,
        p_out_table        OUT SYS_REFCURSOR
    ) AS
        p_count        NUMBER(19) := 0;
        p_output_msg   VARCHAR2(2000);
    BEGIN
        SELECT
            COUNT(*)
        INTO
            p_count
        FROM
            common_dm_nghiep_vu_diff;

        p_out_total_row := p_count;
        p_out_total_page := floor(p_out_total_row / p_per_page);
        OPEN p_out_table FOR
            SELECT
                *
            FROM
                (
                    SELECT
                        ROW_NUMBER() OVER(
                            ORDER BY verify_id
                        ) AS seqnum,
                        a.verify_id,
                        a.verify_date,
                        a.id
                    FROM
                        common_dm_nghiep_vu_diff a
                    WHERE
                        1 = 1
                ) temp
            WHERE
                    seqnum > ( ( p_page - 1 ) * p_per_page )
                AND
                    seqnum <= ( ( p_page ) * p_per_page );

        IF
            MOD(
                p_out_total_row,
                p_per_page
            ) > 0
        THEN
            p_out_total_page := p_out_total_page + 1;
        END IF;

        p_output_code := '00';
    EXCEPTION
        WHEN OTHERS THEN
            p_output_code := sqlcode;
            p_output_msg := substr(
                sqlerrm,
                1,
                1500
            );
            p_out_table := NULL;
            p_out_total_page := 0;
            p_out_total_row := 0;
            p_output_msg := p_output_msg
             || '-GET_LIST_CM_DM_NGHIEP_VU_DIFF-,p_per_page='
             || p_per_page
             || ',p_page='
             || p_page;
            INSERT INTO procedure_log (
                id,
                error_code,
                message,
                id_entity
            ) VALUES (
                (
                    SELECT
                        MAX(id) + 1
                    FROM
                        procedure_log
                ),
                p_output_code,
                p_output_msg,
                0
            );

            COMMIT;
    END;

    PROCEDURE sync_direct_cm_dm_nghiep_vu (
        p_arr           IN table_cm_dm_nghiep_vu,
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    ) AS
        p_index   NUMBER := 0;
    BEGIN
        FOR p_index IN p_arr.first..p_arr.last LOOP
            BEGIN
                INSERT INTO common_dm_nghiep_vu (
                    id,
                    bhxh,
                    bhyt,
                    grp1,
                    grp2,
                    ma,
                    qt,
                    ten,
                    tg,
                    trang_thai
                ) VALUES (
                    p_arr(p_index).id,
                    p_arr(p_index).bhxh,
                    p_arr(p_index).bhyt,
                    p_arr(p_index).grp1,
                    p_arr(p_index).grp2,
                    p_arr(p_index).ma,
                    p_arr(p_index).qt,
                    p_arr(p_index).ten,
                    p_arr(p_index).tg,
                    p_arr(p_index).trang_thai
                );

            END;
        END LOOP;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                p_output_code := sqlcode
                 || '-sync_direct_common_dm_nghiep_vu-'
                 || p_arr(p_index).id
                 || '-'
                 || p_index;

                p_output_msg := substr(
                    sqlerrm,
                    1,
                    2000
                );
                INSERT INTO procedure_log (
                    id,
                    error_code,
                    message,
                    id_entity
                ) VALUES (
                    (
                        SELECT
                            MAX(id) + 1
                        FROM
                            procedure_log
                    ),
                    p_output_code,
                    p_output_msg,
                    p_index
                );

                COMMIT;
            END;
    END;

    PROCEDURE del_cm_dm_nghiep_vu (
        p_output_code   OUT VARCHAR2,
        p_output_msg    OUT VARCHAR2
    )
        AS
    BEGIN
        DELETE common_dm_nghiep_vu;

        DELETE common_dm_nghiep_vu_diff;

        COMMIT;
        p_output_code := '00';
        p_output_msg := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_output_code := sqlcode || '-del_cm_dm_nghiep_vu';
            p_output_msg := substr(
                sqlerrm,
                1,
                2000
            );
            INSERT INTO procedure_log (
                id,
                error_code,
                message,
                id_entity
            ) VALUES (
                (
                    SELECT
                        MAX(id) + 1
                    FROM
                        procedure_log
                ),
                p_output_code,
                p_output_msg,
                1
            );

            COMMIT;
    END;

END pkg_cm_dm_nghiep_vu;
/
