CREATE PROCEDURE cud_common_dm_ngan_hang (
    p_id            IN NUMBER,
    p_ma            IN VARCHAR2,
    p_ten           IN VARCHAR2,
    p_tinh_trang    IN VARCHAR2,
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        (
            p_id IS NOT NULL
        )
    THEN
    --update
        UPDATE common_dm_ngan_hang
            SET
                ma = p_ma,
                ten = p_ten,
                tinh_trang = p_tinh_trang
        WHERE
            id = p_id;

        p_output_msg := 'Update success id=' || p_id;
        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;

    ELSE
    --insert
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_ngan_hang;

        INSERT INTO common_dm_ngan_hang (
            id,
            ma,
            ten,
            tinh_trang
        ) VALUES (
            id_value,
            p_ma,
            p_ten,
            p_tinh_trang
        );

        p_output_msg := 'Insert success id=' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_ngan_hang;
/
