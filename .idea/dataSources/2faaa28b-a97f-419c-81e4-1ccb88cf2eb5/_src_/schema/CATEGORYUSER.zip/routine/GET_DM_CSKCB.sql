CREATE PROCEDURE "GET_DM_CSKCB" (
    p_ma_tinh_thanh   IN VARCHAR,
    p_recordset       OUT SYS_REFCURSOR
)
    AS
BEGIN
    IF
        (
            p_ma_tinh_thanh IS NULL
        )
    THEN
        OPEN p_recordset FOR
            SELECT
                *
            FROM
                common_dm_cskcb;

    ELSE
        OPEN p_recordset FOR
            SELECT
                *
            FROM
                common_dm_cskcb
            WHERE
                    matinhthanh = p_ma_tinh_thanh;

    END IF;
END get_dm_cskcb;
/
