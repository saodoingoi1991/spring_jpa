CREATE PROCEDURE get_dm_don_vi_vsa (
    p_ma_cqbh        IN VARCHAR,
    p_updated_date   IN VARCHAR2,
    p_recordset      OUT SYS_REFCURSOR
)
    AS
BEGIN
    OPEN p_recordset FOR
        SELECT
            a.ten,
            a.ma,
            TO_CHAR(
                a.created_date,
                'dd/MM/yyyy'
            ) created_date,
            TO_CHAR(
                a.updated_date,
                'dd/MM/yyyy'
            ) updated_date,
            a.chon,
            a.cmt_ho_chieu,
            a.dc_lh,
            a.dc_tru_so,
            a.den_so,
            a.dien_thoai,
            a.dn_nha_nuoc,
            a.dung_tl,
            a.dv_tu,
            a.fax,
            a.ghi_chu,
            a.gtinh_ndd,
            a.in_ten_dvi,
            a.ld_giam,
            a.mat_tich,
            a.pha_san,
            a.ly_do_khac,
            a.ld_tang,
            a.loai_dn,
            a.lt_hsl,
            a.lt_nt,
            a.lt_vnd,
            a.ma_dvt,
            a.ms_thue,
            TO_CHAR(
                a.ngay_dkkd,
                'dd/MM/yyyy'
            ) ngay_dkkd,
            TO_CHAR(
                a.ngay_giam,
                'dd/MM/yyyy'
            ) ngay_giam,
            TO_CHAR(
                a.ngay_tang,
                'dd/MM/yyyy'
            ) ngay_tang,
            a.nguoi_dd,
            a.ns_ht,
            TO_CHAR(
                a.nsinh_ndd,
                'dd/MM/yyyy'
            ) nsinh_ndd,
            a.phuong_thuc,
            a.quy_doi,
            a.so_dinh_danh,
            a.so_dkkd,
            a.tat_toan,
            a.td_so,
            a.td_the,
            a.ten_dvcq,
            a.ten_ta,
            a.ten_tat,
            a.tk_gd,
            a.tl_kem_theo,
            a.yt_ml,
            a.ns_htro_khac,
            TO_CHAR(
                a.ngay_dung_tl,
                'dd/MM/yyyy'
            ) ngay_dung_tl,
            a.don_vi_dong,
            a.email,
            a.nguoi_lh,
            a.sdt_nguoi_lh,
            a.email_nguoi_lh,
            TO_CHAR(
                a.ngay_tattoan,
                'dd/MM/yyyy'
            ) ngay_tattoan,
            b.ma ma_khoi_kcb,
            c.ma ma_khoi_ql,
            d.ma_dbhc
        FROM
            common_dm_don_vi a
            LEFT JOIN common_dm_khoi_kcb b ON a.dm_khoi_kcb_id = b.id
            LEFT JOIN common_dm_khoi_quan_ly c ON a.dm_khoi_ql_id = c.id
            LEFT JOIN common_dm_dbhc d ON a.dm_dbhc_id = d.dbhc_id
            LEFT JOIN tst_bhxh_mapping t ON a.dm_bhxh_id = t.id_cqbh_tst
        WHERE
                t.ma_cqbh_tst = p_ma_cqbh
            AND
                p_updated_date = (
                    CASE
                        WHEN p_updated_date LIKE '____' THEN TO_CHAR(
                            a.updated_date,
                            'yyyy'
                        )
                        WHEN p_updated_date LIKE '______' THEN TO_CHAR(
                            a.updated_date,
                            'yyyyMM'
                        )
                    END
                );

    
END get_dm_don_vi_vsa;
/
