CREATE PROCEDURE cud_common_dm_dbhc (
    p_id                  IN NUMBER,
    p_ten                 IN VARCHAR2,
    p_ma_cha              IN VARCHAR2,
    p_ma_dbhc             IN VARCHAR2,
    p_tinh_trang          IN VARCHAR2,
    p_can_cu              IN VARCHAR2,
    p_ngay_hieu_luc       IN VARCHAR2,
    p_ngay_het_hieu_luc   IN VARCHAR2,
    p_dbhc_id             IN VARCHAR2,
    p_output_code         OUT VARCHAR2,
    p_output_msg          OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN
    --update
        UPDATE common_dm_dbhc
            SET
                ten = p_ten,
                ma_cha = p_ma_cha,
                ma_dbhc = p_ma_dbhc,
                tinh_trang = p_tinh_trang,
                can_cu = p_can_cu,
                ngay_hieu_luc = TO_DATE(
                    p_ngay_hieu_luc,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                ngay_het_hieu_luc = TO_DATE(
                    p_ngay_het_hieu_luc,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                dbhc_id = p_dbhc_id
        WHERE
            id = p_id;

--        p_output_msg := 'Update success id=' || p_id;
        
        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;
    ELSE
    --insert
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_dbhc;

        INSERT INTO common_dm_dbhc (
            id,
            ten,
            ma_cha,
            ma_dbhc,
            tinh_trang,
            can_cu,
            ngay_hieu_luc,
            ngay_het_hieu_luc,
            dbhc_id
        ) VALUES (
            id_value,
            p_ten,
            p_ma_cha,
            p_ma_dbhc,
            p_tinh_trang,
            p_can_cu,
            TO_DATE(
                p_ngay_hieu_luc,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            TO_DATE(
                p_ngay_het_hieu_luc,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_dbhc_id
        );

        p_output_msg := 'Insert success id =' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_dbhc;
/
