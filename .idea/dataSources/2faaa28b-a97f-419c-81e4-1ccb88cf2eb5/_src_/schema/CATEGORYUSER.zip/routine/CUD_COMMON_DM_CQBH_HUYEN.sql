CREATE PROCEDURE cud_common_dm_cqbh_huyen (
    p_id                  IN NUMBER,
    p_ma_cqbh_huyen       IN VARCHAR2,
    p_ten_cqbh_huyen      IN VARCHAR2,
    p_ma_cqbh_tinh        IN VARCHAR2,
    p_dia_chi             IN VARCHAR2,
    p_xa_phuong           IN VARCHAR2,
    p_quan_huyen          IN VARCHAR2,
    p_tinh_tp             IN VARCHAR2,
    p_so_dien_thoai       IN VARCHAR2,
    p_ngay_hieu_luc       IN VARCHAR2,
    p_ngay_het_hieu_luc   IN VARCHAR2,
    p_output_code         OUT VARCHAR2,
    p_output_msg          OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN
    --update
        UPDATE common_dm_cqbh_huyen
            SET
                id = p_id,
                ma_cqbh_huyen = p_ma_cqbh_huyen,
                ten_cqbh_huyen = p_ten_cqbh_huyen,
                ma_cqbh_tinh = p_ma_cqbh_tinh,
                dia_chi = p_dia_chi,
                xa_phuong = p_xa_phuong,
                quan_huyen = p_quan_huyen,
                tinh_tp = p_tinh_tp,
                so_dien_thoai = p_so_dien_thoai,
                ngay_hieu_luc = TO_DATE(
                    p_ngay_hieu_luc,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                ngay_het_hieu_luc = TO_DATE(
                    p_ngay_het_hieu_luc,
                    'dd-mm-yyyy HH24:mi:ss'
                )
        WHERE
            id = p_id;

--        p_output_msg := 'Update success id=' || p_id;
        
        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;
        
    ELSE
    --insert
        INSERT INTO common_dm_cqbh_huyen (
            ma_cqbh_huyen,
            ten_cqbh_huyen,
            ma_cqbh_tinh,
            dia_chi,
            xa_phuong,
            quan_huyen,
            tinh_tp,
            so_dien_thoai,
            ngay_hieu_luc,
            ngay_het_hieu_luc
        ) VALUES (
            p_ma_cqbh_huyen,
            p_ten_cqbh_huyen,
            p_ma_cqbh_tinh,
            p_dia_chi,
            p_xa_phuong,
            p_quan_huyen,
            p_tinh_tp,
            p_so_dien_thoai,
            TO_DATE(
                p_ngay_hieu_luc,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            TO_DATE(
                p_ngay_het_hieu_luc,
                'dd-mm-yyyy HH24:mi:ss'
            )
        );
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) )
            END
        INTO
            id_value
        FROM
            common_dm_cqbh_huyen;
        p_output_msg := 'Insert success id =' || id_value;
    END IF;
    COMMIT;
    p_output_code := '00';    
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );        
        COMMIT;
END cud_common_dm_cqbh_huyen;
/
