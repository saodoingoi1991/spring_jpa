CREATE PROCEDURE GET_DM_KHOI_TK_ODTS  (
                      p_recordset OUT SYS_REFCURSOR) AS 
BEGIN
 OPEN p_recordset FOR
  select *
  from COMMON_DM_KHOI_THONG_KE;
END GET_DM_KHOI_TK_ODTS;
/
