CREATE PROCEDURE get_common_huyen_by_ma (
    p_ma            IN VARCHAR2,
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2,
    p_out_table     OUT SYS_REFCURSOR
) IS
    p_code   VARCHAR2(100);
BEGIN
    p_output_code := '00';
    p_output_msg := 'Thanh cong';
    p_code := p_ma || '%';
    OPEN p_out_table FOR
        SELECT
            *
        FROM
            common_dm_cqbh_huyen
        WHERE
            ma_cqbh_huyen LIKE p_code;

EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            1500
        );
        p_out_table := NULL;
        INSERT INTO procedure_log (
            id,
            error_code,
            message
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            'GET_COMMON_HUYEN_BY_MA|Code =' || p_ma || p_output_code,
            p_output_msg
        );

        COMMIT;
END get_common_huyen_by_ma;
/
