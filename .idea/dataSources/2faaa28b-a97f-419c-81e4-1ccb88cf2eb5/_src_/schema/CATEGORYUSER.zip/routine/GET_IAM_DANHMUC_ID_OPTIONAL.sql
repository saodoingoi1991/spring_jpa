CREATE PROCEDURE GET_IAM_DANHMUC_ID_OPTIONAL (
    p_view             IN VARCHAR2 DEFAULT NULL,    
    p_output_code      OUT VARCHAR2,
    p_out_table        OUT SYS_REFCURSOR
) AS
    p_query        VARCHAR2(4000);   
    p_output_msg   VARCHAR2(2000);
BEGIN
    p_query := '';   
    p_query := 'select '||p_view||' from IAM_DANHMUC_ID';    
    OPEN p_out_table FOR p_query;
END GET_IAM_DANHMUC_ID_OPTIONAL;
/
