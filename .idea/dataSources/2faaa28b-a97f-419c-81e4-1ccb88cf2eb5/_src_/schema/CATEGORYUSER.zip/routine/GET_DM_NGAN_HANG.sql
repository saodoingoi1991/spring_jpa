CREATE PROCEDURE get_dm_ngan_hang ( p_recordset   OUT SYS_REFCURSOR )
    AS
BEGIN
    OPEN p_recordset FOR
        SELECT
            *
        FROM
            common_dm_ngan_hang;

END get_dm_ngan_hang;
/
