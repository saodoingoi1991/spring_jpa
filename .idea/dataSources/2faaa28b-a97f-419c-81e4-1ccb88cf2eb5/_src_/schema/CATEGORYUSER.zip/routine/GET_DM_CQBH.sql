CREATE PROCEDURE get_dm_cqbh (
    p_ma_cqbh_tinh   IN VARCHAR2,
    p_recordset      OUT SYS_REFCURSOR
)
    AS
BEGIN
    IF
        p_ma_cqbh_tinh IS NULL
    THEN
        OPEN p_recordset FOR
            SELECT
                cqbhtinh.ma_cqbh_tinh,
                cqbhtinh.ten_cqbh_tinh,
                cqbhhuyen.ma_cqbh_huyen,
                cqbhhuyen.ten_cqbh_huyen
            FROM
                common_dm_cqbh_tinh cqbhtinh
                LEFT JOIN common_dm_cqbh_huyen cqbhhuyen ON cqbhtinh.ma_cqbh_tinh = cqbhhuyen.ma_cqbh_tinh
            ORDER BY cqbhtinh.ma_cqbh_tinh;

    ELSE
        OPEN p_recordset FOR
            SELECT
                cqbhtinh.ma_cqbh_tinh,
                cqbhtinh.ten_cqbh_tinh,
                cqbhhuyen.ma_cqbh_huyen,
                cqbhhuyen.ten_cqbh_huyen
            FROM
                common_dm_cqbh_tinh cqbhtinh
                LEFT JOIN common_dm_cqbh_huyen cqbhhuyen ON cqbhtinh.ma_cqbh_tinh = cqbhhuyen.ma_cqbh_tinh
            WHERE
                cqbhtinh.ma_cqbh_tinh = p_ma_cqbh_tinh
            ORDER BY cqbhtinh.ma_cqbh_tinh;

    END IF;
END get_dm_cqbh;
/
