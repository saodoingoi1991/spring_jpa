CREATE PROCEDURE delete_common_dm (
    p_id            IN NUMBER,
    p_danhmuc_id    IN VARCHAR2,
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2
)
    IS
BEGIN
    p_output_code := '00';
    p_output_msg := 'Thanh cong';
    EXECUTE IMMEDIATE 'DELETE ' || p_danhmuc_id || ' WHERE ID =' || p_id;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            1500
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_danhmuc_id || '_delete_' || p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END delete_common_dm;
/
