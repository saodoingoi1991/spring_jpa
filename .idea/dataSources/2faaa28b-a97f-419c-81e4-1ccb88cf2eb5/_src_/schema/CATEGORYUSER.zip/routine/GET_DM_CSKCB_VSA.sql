CREATE PROCEDURE get_dm_cskcb_vsa (
    p_ma_tinh_thanh   IN VARCHAR,
    p_updated_date    IN VARCHAR2,
    p_recordset       OUT SYS_REFCURSOR
)
    AS
BEGIN
    IF
        (
            p_ma_tinh_thanh IS NULL
        AND
            p_updated_date IS NULL
        )
    THEN
        OPEN p_recordset FOR
            SELECT
                ma,
                ten,
                matinhthanh,
                tuyencmkt,
                hangbenhvien
            FROM
                common_dm_cskcb;

    ELSE
        OPEN p_recordset FOR
            SELECT
                ma,
                ten,
                matinhthanh,
                tuyencmkt,
                hangbenhvien
            FROM
                common_dm_cskcb
            WHERE
                    matinhthanh = p_ma_tinh_thanh
                AND
                    p_updated_date = (
                        CASE
                            WHEN p_updated_date LIKE '____' THEN TO_CHAR(
                                ngaydieuchinh,
                                'yyyy'
                            )
                            WHEN p_updated_date LIKE '______' THEN TO_CHAR(
                                ngaydieuchinh,
                                'yyyyMM'
                            )
                        END
                    );

    END IF;
END get_dm_cskcb_vsa;
/
