CREATE PROCEDURE cud_common_dm_nghiep_vu (
    p_id            IN NUMBER,
    p_bhxh          IN NUMBER,
    p_bhyt          IN NUMBER,
    p_grp1          IN NUMBER,
    p_grp2          IN NUMBER,
    p_ma            IN VARCHAR2,
    p_qt            IN NUMBER,
    p_ten           IN VARCHAR2,
    p_tg            IN NUMBER,
    p_trang_thai    IN NUMBER,
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN
    --update
        UPDATE common_dm_nghiep_vu
            SET
                bhxh = p_bhxh,
                bhyt = p_bhyt,
                grp1 = p_grp1,
                grp2 = p_grp2,
                ma = p_ma,
                qt = p_qt,
                ten = p_ten,
                tg = p_tg,
                trang_thai = p_trang_thai
        WHERE
            id = p_id;

--        p_output_msg := 'Update success id =' || p_id;

        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;

    ELSE
    --insert
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_nghiep_vu;

        INSERT INTO common_dm_nghiep_vu (
            id,
            bhxh,
            bhyt,
            grp1,
            grp2,
            ma,
            qt,
            ten,
            tg,
            trang_thai
        ) VALUES (
            id_value,
            p_bhxh,
            p_bhyt,
            p_grp1,
            p_grp2,
            p_ma,
            p_qt,
            p_ten,
            p_tg,
            p_trang_thai
        );

        p_output_msg := 'Insert success id=' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_nghiep_vu;
/
