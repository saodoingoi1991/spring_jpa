CREATE PROCEDURE cud_common_dm_phong_ban (
    p_id                 IN NUMBER,
    p_ten_tieng_viet     IN VARCHAR2,
    p_ten_tieng_anh      IN VARCHAR2,
    p_ten_viet_tat       IN VARCHAR2,
    p_tinh_thanh_id      IN NUMBER,
    p_dia_chi            IN VARCHAR2,
    p_dien_thoai         IN VARCHAR2,
    p_email              IN VARCHAR2,
    p_fax                IN VARCHAR2,
    p_ma_so_thue         IN VARCHAR2,
    p_db_name            IN VARCHAR2,
    p_last_update        IN DATE,
    p_ma_don_vi          IN VARCHAR2,
    p_donvi_cha_id       IN NUMBER,
    p_cap_don_vi         IN NUMBER,
    p_loai_hinh          IN NUMBER,
    p_ma_kcb             IN VARCHAR2,
    p_so_tai_khoan       IN VARCHAR2,
    p_ngan_hang          IN VARCHAR2,
    p_loai_hinh_don_vi   IN NUMBER,
    p_sl_diem_kho        IN NUMBER,
    p_co_quan_tong_cuc   IN NUMBER,
    p_xa_phuong_id       IN NUMBER,
    p_stt_cap            IN NUMBER,
    p_pc_khu_vuc         IN NUMBER,
    p_output_code        OUT VARCHAR2,
    p_output_msg         OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN
    --update
        UPDATE common_dm_phong_ban
            SET
                ten_tieng_viet = p_ten_tieng_viet,
                ten_tieng_anh = p_ten_tieng_anh,
                ten_viet_tat = p_ten_viet_tat,
                tinh_thanh_id = p_tinh_thanh_id,
                dia_chi = p_dia_chi,
                dien_thoai = p_dien_thoai,
                email = p_email,
                fax = p_fax,
                ma_so_thue = p_ma_so_thue,
                db_name = p_db_name,
                last_update = p_last_update,
                ma_don_vi = p_ma_don_vi,
                donvi_cha_id = p_donvi_cha_id,
                cap_don_vi = p_cap_don_vi,
                loai_hinh = p_loai_hinh,
                ma_kcb = p_ma_kcb,
                so_tai_khoan = p_so_tai_khoan,
                ngan_hang = p_ngan_hang,
                loai_hinh_don_vi = p_loai_hinh_don_vi,
                sl_diem_kho = p_sl_diem_kho,
                co_quan_tong_cuc = p_co_quan_tong_cuc,
                xa_phuong_id = p_xa_phuong_id,
                stt_cap = p_stt_cap,
                pc_khu_vuc = p_pc_khu_vuc
        WHERE
            id = p_id;

--        p_output_msg := 'Update success id=' || p_id;

        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;

    ELSE
    --insert
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_phong_ban;

        INSERT INTO common_dm_phong_ban (
            id,
            ten_tieng_viet,
            ten_tieng_anh,
            ten_viet_tat,
            tinh_thanh_id,
            dia_chi,
            dien_thoai,
            email,
            fax,
            ma_so_thue,
            db_name,
            last_update,
            ma_don_vi,
            donvi_cha_id,
            cap_don_vi,
            loai_hinh,
            ma_kcb,
            so_tai_khoan,
            ngan_hang,
            loai_hinh_don_vi,
            sl_diem_kho,
            co_quan_tong_cuc,
            xa_phuong_id,
            stt_cap,
            pc_khu_vuc
        ) VALUES (
            id_value,
            p_ten_tieng_viet,
            p_ten_tieng_anh,
            p_ten_viet_tat,
            p_tinh_thanh_id,
            p_dia_chi,
            p_dien_thoai,
            p_email,
            p_fax,
            p_ma_so_thue,
            p_db_name,
            p_last_update,
            p_ma_don_vi,
            p_donvi_cha_id,
            p_cap_don_vi,
            p_loai_hinh,
            p_ma_kcb,
            p_so_tai_khoan,
            p_ngan_hang,
            p_loai_hinh_don_vi,
            p_sl_diem_kho,
            p_co_quan_tong_cuc,
            p_xa_phuong_id,
            p_stt_cap,
            p_pc_khu_vuc
        );

        p_output_msg := 'Insert success id=' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_phong_ban;
/
