CREATE PROCEDURE get_dm_phong_ban ( p_recordset   OUT SYS_REFCURSOR )
    AS
BEGIN
    OPEN p_recordset FOR
        SELECT
            *
        FROM
            common_dm_phong_ban;
  --close p_recordset;

END get_dm_phong_ban;
/
