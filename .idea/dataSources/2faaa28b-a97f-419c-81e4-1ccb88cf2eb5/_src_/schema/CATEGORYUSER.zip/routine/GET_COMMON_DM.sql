CREATE PROCEDURE get_common_dm (
    p_danhmuc_id       IN VARCHAR2, --ID_DANHMUC : TEN BANG DU LIEU
    p_per_page         IN NUMBER, -- SO ROW TREN 1 TRANG (PHAN TRANG)
    p_page             IN NUMBER, -- SO TRANG
    p_where            IN VARCHAR2 DEFAULT NULL, --DIEU KIEN WHERE VIDU: AND ID =1 AND TEN ='ABC'
    p_view             IN VARCHAR2 DEFAULT NULL, -- DANH SACH TRUONG CAN LAY THONG TIN: VIDU: ID,TEN,MA,...
    p_out_total_page   OUT NUMBER,  
    p_out_total_row    OUT NUMBER,
    p_output_code      OUT VARCHAR2,
    p_out_table        OUT SYS_REFCURSOR
) AS
    p_query        VARCHAR2(4000);
    p_count        NUMBER(19);
    p_output_msg   VARCHAR2(2000);
BEGIN
    p_query := '';
    p_count := 0;
    EXECUTE IMMEDIATE 'select count(*) from (select row_number() OVER (  order by id  ) AS seqnum,a.* from '
     || p_danhmuc_id
     || ' a where 1=1 '
     || p_where
     || ')' INTO
        p_count;
    p_query := 'select '
     || p_view
     || ' from (select row_number() OVER (  order by id  ) AS seqnum,a.* from '
     || p_danhmuc_id
     || ' a where 1=1'
     || p_where
     || ') where seqnum>'
     || ( ( p_page - 1 ) * p_per_page )
     || ' and seqnum<='
     || ( ( p_page ) * p_per_page );   

    p_out_total_row := p_count;
    p_out_total_page := floor(p_out_total_row / p_per_page);
    OPEN p_out_table FOR p_query;

    IF
        MOD(
            p_out_total_row,
            p_per_page
        ) > 0
    THEN
        p_out_total_page := p_out_total_page + 1;
    END IF;

    p_output_code := '00';    

EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            1500
        );
        p_out_table := NULL;
        p_out_total_page := 0;
        p_out_total_row := 0;
        p_output_msg := p_output_msg
         || ',p_danhmuc_id ='
         || p_danhmuc_id
         || ',p_per_page='
         || p_per_page
         || ',p_page='
         || p_page
         || ',p_where='
         || p_where
         || ',p_view='
         || p_view;

        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_danhmuc_id || '_' || p_output_code,
            p_output_msg,
            0
        );

        COMMIT;
END get_common_dm;
/
