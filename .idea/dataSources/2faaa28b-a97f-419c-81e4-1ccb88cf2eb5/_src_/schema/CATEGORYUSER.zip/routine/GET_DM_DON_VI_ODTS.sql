CREATE PROCEDURE get_dm_don_vi_odts (
    p_ma_cqbh        IN VARCHAR,
    p_updated_date   IN VARCHAR2,
    p_recordset      OUT SYS_REFCURSOR
)
    AS
BEGIN
    IF
            p_ma_cqbh IS NOT NULL
        AND
            p_updated_date IS NOT NULL
    THEN
        OPEN p_recordset FOR
            SELECT
                dv.id id,
                dbhctinh.ma_dbhc matinh,
                dbhchuyen.ma_dbhc mahuyen,
                dv.so_dkkd,
                dv.ms_thue,
                dv.nguoi_dd,
                dv.ma_dvt madvikcb,
                kcb.ma makhoikcb,
                dv.dc_lh,
                dv.ma,
                dv.ten,
                dv.loai_dn,
                dv.dc_tru_so,
                dv.dien_thoai,
                dv.fax,
                dv.tk_gd,
                tk.ma makhoitk,
                ql.ma makhoiql,
                ql.ten tenkhoiql,
                    CASE
                        WHEN dv.mat_tich = 1 THEN '- Bỏ trốn '
                    END
                 || CASE
                        WHEN dv.pha_san = 1 THEN '- Phá sản '
                    END
                 || CASE
                        WHEN dv.ly_do_khac = 1 THEN '- Ngừng GD '
                    END
                 || CASE dv.ld_giam
                        WHEN '01'   THEN '- Giải thể '
                        WHEN '02'   THEN '- Sát nhập '
                        WHEN '03'   THEN '- Chuyên quản '
                        WHEN '04'   THEN '- Chuyển tỉnh '
                        WHEN '05'   THEN '- Chuyển khối '
                    END
                tinhtrang
            FROM
                common_dm_don_vi dv
                LEFT JOIN common_dm_khoi_quan_ly ql ON ql.id = dv.dm_khoi_ql_id
                LEFT JOIN common_dm_khoi_thong_ke tk ON tk.id = ql.dm_khoi_tk_id
                LEFT JOIN common_dm_dbhc dbhctinh ON dbhctinh.dbhc_id = dv.ma_tinh_kcb_id
                LEFT JOIN common_dm_dbhc dbhchuyen ON dbhchuyen.dbhc_id = dv.ma_huyen_kcb_id
                LEFT JOIN common_dm_khoi_kcb kcb ON kcb.id = dv.dm_khoi_kcb_id
                LEFT JOIN tst_bhxh_mapping t ON dv.dm_bhxh_id = t.id_cqbh_tst
            WHERE
                    t.ma_cqbh_tst = p_ma_cqbh
                AND
                    p_updated_date = (
                        CASE
                            WHEN p_updated_date LIKE '____' THEN TO_CHAR(
                                dv.updated_date,
                                'yyyy'
                            )
                            WHEN p_updated_date LIKE '______' THEN TO_CHAR(
                                dv.updated_date,
                                'yyyyMM'
                            )
                        END
                    );

    ELSE
        dbms_output.put_line('Output from PL/SQL...');
    END IF;
END get_dm_don_vi_odts;
/
