CREATE PROCEDURE cud_common_dm_don_vi (
    p_id                IN NUMBER,
    p_created_date      IN TIMESTAMP,
    p_updated_date      IN TIMESTAMP,
    p_chon              IN NUMBER,
    p_cmt_ho_chieu      IN VARCHAR2,
    p_dc_lh             IN VARCHAR2,
    p_dc_tru_so         IN VARCHAR2,
    p_den_so            IN NUMBER,
    p_dien_thoai        IN VARCHAR2,
    p_dn_nha_nuoc       IN NUMBER,
    p_dung_tl           IN NUMBER,
    p_dv_tu             IN NUMBER,
    p_fax               IN VARCHAR2,
    p_ghi_chu           IN VARCHAR2,
    p_gtinh_ndd         IN NUMBER,
    p_in_ten_dvi        IN NUMBER,
    p_ld_giam           IN VARCHAR2,
    p_mat_tich          IN NUMBER,
    p_pha_san           IN NUMBER,
    p_ly_do_khac        IN NUMBER,
    p_ld_tang           IN VARCHAR2,
    p_loai_dn           IN VARCHAR2,
    p_lt_hsl            IN NUMBER,
    p_lt_nt             IN NUMBER,
    p_lt_vnd            IN NUMBER,
    p_ma                IN VARCHAR2,
    p_ma_dvt            IN VARCHAR2,
    p_ms_thue           IN VARCHAR2,
    p_ngay_dkkd         IN VARCHAR2,--date
    p_ngay_giam         IN VARCHAR2,--date
    p_ngay_tang         IN VARCHAR2,--date 
    p_nguoi_dd          IN VARCHAR2,
    p_ns_ht             IN NUMBER,
    p_nsinh_ndd         IN VARCHAR2,--date
    p_phuong_thuc       IN VARCHAR2,
    p_quy_doi           IN NUMBER,
    p_so_dinh_danh      IN VARCHAR2,
    p_so_dkkd           IN VARCHAR2,
    p_tat_toan          IN NUMBER,
    p_td_so             IN NUMBER,
    p_td_the            IN NUMBER,
    p_ten               IN VARCHAR2,
    p_ten_dvcq          IN VARCHAR2,
    p_ten_ta            IN VARCHAR2,
    p_ten_tat           IN VARCHAR2,
    p_tk_gd             IN VARCHAR2,
    p_tl_kem_theo       IN VARCHAR2,
    p_yt_ml             IN NUMBER,
    p_ns_htro_khac      IN NUMBER,
    p_ngay_dung_tl      IN VARCHAR2,--date
    p_don_vi_dong       IN NVARCHAR2,
    p_email             IN NVARCHAR2,
    p_nguoi_lh          IN NVARCHAR2,
    p_sdt_nguoi_lh      IN NVARCHAR2,
    p_email_nguoi_lh    IN NVARCHAR2,
    p_ngay_tattoan      IN VARCHAR2,--date
    p_huu_tri           IN VARCHAR2,
    p_dm_bhxh_id        IN NUMBER,
    p_dm_dbhc_id        IN NUMBER,
    p_dm_dt_kcb_id      IN NUMBER,
    p_dm_khoi_kcb_id    IN NUMBER,
    p_dm_khoi_ql_id     IN NUMBER,
    p_dm_ngoai_te_id    IN NUMBER,
    p_dm_vung_id        IN NUMBER,
    p_ma_huyen_kcb_id   IN NUMBER,
    p_ma_tinh_kcb_id    IN NUMBER,
    p_ma_xa_kcb_id      IN NUMBER,
    p_qtich_ndd_id      IN NUMBER,
    p_user_id           IN NUMBER,
    p_ma_dvt_cu         IN VARCHAR2,
    p_thang_tl          IN VARCHAR2,
    p_ty_le_nsnn        IN NUMBER,
    p_is_dvi_no         IN NUMBER,
    p_ngay_dvi_no       IN VARCHAR2,--date
    p_user_dvi_no_id    IN NUMBER,
    p_output_code       OUT VARCHAR2,
    p_output_msg        OUT VARCHAR2
) IS
    id_value   NUMBER;
    p_md5      VARCHAR2(4000) := '';
BEGIN
    IF
        p_id IS NOT NULL
    THEN
    --update
        SELECT
            dbms_obfuscation_toolkit.md5(
                input   => utl_raw.cast_to_raw(p_id
                 || p_chon
                 || p_cmt_ho_chieu
                 || p_dc_lh
                 || p_dc_tru_so
                 || p_den_so
                 || p_dien_thoai
                 || p_dn_nha_nuoc
                 || p_dung_tl
                 || p_dv_tu
                 || p_fax
                 || p_ghi_chu
                 || p_gtinh_ndd
                 || p_in_ten_dvi
                 || p_ld_giam
                 || p_mat_tich
                 || p_pha_san
                 || p_ly_do_khac
                 || p_ld_tang
                 || p_loai_dn
                 || p_lt_hsl
                 || p_lt_nt
                 || p_lt_vnd
                 || p_ma
                 || p_ma_dvt
                 || p_ms_thue
                 || p_ngay_dkkd
                 || p_ngay_giam
                 || p_ngay_tang
                 || p_nguoi_dd
                 || p_ns_ht
                 || p_nsinh_ndd
                 || p_phuong_thuc
                 || p_quy_doi
                 || p_so_dinh_danh
                 || p_so_dkkd
                 || p_tat_toan
                 || p_td_so
                 || p_td_the
                 || p_ten
                 || p_ten_dvcq
                 || p_ten_ta
                 || p_ten_tat
                 || p_tk_gd
                 || p_tl_kem_theo
                 || p_yt_ml
                 || p_ns_htro_khac
                 || p_ngay_dung_tl
                 || p_don_vi_dong
                 || p_email
                 || p_nguoi_lh
                 || p_sdt_nguoi_lh
                 || p_email_nguoi_lh
                 || p_ngay_tattoan
                 || p_huu_tri
                 || p_dm_bhxh_id
                 || p_dm_dbhc_id
                 || p_dm_dt_kcb_id
                 || p_dm_khoi_kcb_id
                 || p_dm_khoi_ql_id
                 || p_dm_ngoai_te_id
                 || p_dm_vung_id
                 || p_ma_huyen_kcb_id
                 || p_ma_tinh_kcb_id
                 || p_ma_xa_kcb_id
                 || p_qtich_ndd_id
                 || p_user_id
                 || p_ma_dvt_cu
                 || p_thang_tl
                 || p_ty_le_nsnn
                 || p_is_dvi_no
                 || p_ngay_dvi_no
                 || p_user_dvi_no_id)
            )
        INTO
            p_md5
        FROM
            dual;

        UPDATE common_dm_don_vi
            SET
                updated_date = SYSDATE,
                chon = p_chon,
                cmt_ho_chieu = p_cmt_ho_chieu,
                dc_lh = p_dc_lh,
                dc_tru_so = p_dc_tru_so,
                den_so = p_den_so,
                dien_thoai = p_dien_thoai,
                dn_nha_nuoc = p_dn_nha_nuoc,
                dung_tl = p_dung_tl,
                dv_tu = p_dv_tu,
                fax = p_fax,
                ghi_chu = p_ghi_chu,
                gtinh_ndd = p_gtinh_ndd,
                in_ten_dvi = p_in_ten_dvi,
                ld_giam = p_ld_giam,
                mat_tich = p_mat_tich,
                pha_san = p_pha_san,
                ly_do_khac = p_ly_do_khac,
                ld_tang = p_ld_tang,
                loai_dn = p_loai_dn,
                lt_hsl = p_lt_hsl,
                lt_nt = p_lt_nt,
                lt_vnd = p_lt_vnd,
                ma = p_ma,
                ma_dvt = p_ma_dvt,
                ms_thue = p_ms_thue,
                ngay_dkkd = TO_DATE(
                    p_ngay_dkkd,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                ngay_giam = TO_DATE(
                    p_ngay_giam,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                ngay_tang = TO_DATE(
                    p_ngay_tang,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                nguoi_dd = p_nguoi_dd,
                ns_ht = p_ns_ht,
                nsinh_ndd = TO_DATE(
                    p_nsinh_ndd,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                phuong_thuc = p_phuong_thuc,
                quy_doi = p_quy_doi,
                so_dinh_danh = p_so_dinh_danh,
                so_dkkd = p_so_dkkd,
                tat_toan = p_tat_toan,
                td_so = p_td_so,
                td_the = p_td_the,
                ten = p_ten,
                ten_dvcq = p_ten_dvcq,
                ten_ta = p_ten_ta,
                ten_tat = p_ten_tat,
                tk_gd = p_tk_gd,
                tl_kem_theo = p_tl_kem_theo,
                yt_ml = p_yt_ml,
                ns_htro_khac = p_ns_htro_khac,
                ngay_dung_tl = TO_DATE(
                    p_ngay_dung_tl,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                don_vi_dong = p_don_vi_dong,
                email = p_email,
                nguoi_lh = p_nguoi_lh,
                sdt_nguoi_lh = p_sdt_nguoi_lh,
                email_nguoi_lh = p_email_nguoi_lh,
                ngay_tattoan = TO_DATE(
                    p_ngay_tattoan,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                huu_tri = p_huu_tri,
                dm_bhxh_id = p_dm_bhxh_id,
                dm_dbhc_id = p_dm_dbhc_id,
                dm_dt_kcb_id = p_dm_dt_kcb_id,
                dm_khoi_kcb_id = p_dm_khoi_kcb_id,
                dm_khoi_ql_id = p_dm_khoi_ql_id,
                dm_ngoai_te_id = p_dm_ngoai_te_id,
                dm_vung_id = p_dm_vung_id,
                ma_huyen_kcb_id = p_ma_huyen_kcb_id,
                ma_tinh_kcb_id = p_ma_tinh_kcb_id,
                ma_xa_kcb_id = p_ma_xa_kcb_id,
                qtich_ndd_id = p_qtich_ndd_id,
                user_id = p_user_id,
                ma_dvt_cu = p_ma_dvt_cu,
                thang_tl = p_thang_tl,
                ty_le_nsnn = p_ty_le_nsnn,
                is_dvi_no = p_is_dvi_no,
                ngay_dvi_no = TO_DATE(
                    p_ngay_dvi_no,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                user_dvi_no_id = p_user_dvi_no_id,
                md5 = p_md5
        WHERE
            id = p_id;

        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;

    ELSE
    --insert
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_don_vi;

        SELECT
            dbms_obfuscation_toolkit.md5(
                input   => utl_raw.cast_to_raw(id_value
                 || p_chon
                 || p_cmt_ho_chieu
                 || p_dc_lh
                 || p_dc_tru_so
                 || p_den_so
                 || p_dien_thoai
                 || p_dn_nha_nuoc
                 || p_dung_tl
                 || p_dv_tu
                 || p_fax
                 || p_ghi_chu
                 || p_gtinh_ndd
                 || p_in_ten_dvi
                 || p_ld_giam
                 || p_mat_tich
                 || p_pha_san
                 || p_ly_do_khac
                 || p_ld_tang
                 || p_loai_dn
                 || p_lt_hsl
                 || p_lt_nt
                 || p_lt_vnd
                 || p_ma
                 || p_ma_dvt
                 || p_ms_thue
                 || p_ngay_dkkd
                 || p_ngay_giam
                 || p_ngay_tang
                 || p_nguoi_dd
                 || p_ns_ht
                 || p_nsinh_ndd
                 || p_phuong_thuc
                 || p_quy_doi
                 || p_so_dinh_danh
                 || p_so_dkkd
                 || p_tat_toan
                 || p_td_so
                 || p_td_the
                 || p_ten
                 || p_ten_dvcq
                 || p_ten_ta
                 || p_ten_tat
                 || p_tk_gd
                 || p_tl_kem_theo
                 || p_yt_ml
                 || p_ns_htro_khac
                 || p_ngay_dung_tl
                 || p_don_vi_dong
                 || p_email
                 || p_nguoi_lh
                 || p_sdt_nguoi_lh
                 || p_email_nguoi_lh
                 || p_ngay_tattoan
                 || p_huu_tri
                 || p_dm_bhxh_id
                 || p_dm_dbhc_id
                 || p_dm_dt_kcb_id
                 || p_dm_khoi_kcb_id
                 || p_dm_khoi_ql_id
                 || p_dm_ngoai_te_id
                 || p_dm_vung_id
                 || p_ma_huyen_kcb_id
                 || p_ma_tinh_kcb_id
                 || p_ma_xa_kcb_id
                 || p_qtich_ndd_id
                 || p_user_id
                 || p_ma_dvt_cu
                 || p_thang_tl
                 || p_ty_le_nsnn
                 || p_is_dvi_no
                 || p_ngay_dvi_no
                 || p_user_dvi_no_id)
            )
        INTO
            p_md5
        FROM
            dual;

        INSERT INTO common_dm_don_vi (
            id,
            created_date,
            updated_date,
            chon,
            cmt_ho_chieu,
            dc_lh,
            dc_tru_so,
            den_so,
            dien_thoai,
            dn_nha_nuoc,
            dung_tl,
            dv_tu,
            fax,
            ghi_chu,
            gtinh_ndd,
            in_ten_dvi,
            ld_giam,
            mat_tich,
            pha_san,
            ly_do_khac,
            ld_tang,
            loai_dn,
            lt_hsl,
            lt_nt,
            lt_vnd,
            ma,
            ma_dvt,
            ms_thue,
            ngay_dkkd,
            ngay_giam,
            ngay_tang,
            nguoi_dd,
            ns_ht,
            nsinh_ndd,
            phuong_thuc,
            quy_doi,
            so_dinh_danh,
            so_dkkd,
            tat_toan,
            td_so,
            td_the,
            ten,
            ten_dvcq,
            ten_ta,
            ten_tat,
            tk_gd,
            tl_kem_theo,
            yt_ml,
            ns_htro_khac,
            ngay_dung_tl,
            don_vi_dong,
            email,
            nguoi_lh,
            sdt_nguoi_lh,
            email_nguoi_lh,
            ngay_tattoan,
            huu_tri,
            dm_bhxh_id,
            dm_dbhc_id,
            dm_dt_kcb_id,
            dm_khoi_kcb_id,
            dm_khoi_ql_id,
            dm_ngoai_te_id,
            dm_vung_id,
            ma_huyen_kcb_id,
            ma_tinh_kcb_id,
            ma_xa_kcb_id,
            qtich_ndd_id,
            user_id,
            ma_dvt_cu,
            thang_tl,
            ty_le_nsnn,
            is_dvi_no,
            ngay_dvi_no,
            user_dvi_no_id,
            md5
        ) VALUES (
            id_value,
            SYSDATE,
            SYSDATE,
            p_chon,
            p_cmt_ho_chieu,
            p_dc_lh,
            p_dc_tru_so,
            p_den_so,
            p_dien_thoai,
            p_dn_nha_nuoc,
            p_dung_tl,
            p_dv_tu,
            p_fax,
            p_ghi_chu,
            p_gtinh_ndd,
            p_in_ten_dvi,
            p_ld_giam,
            p_mat_tich,
            p_pha_san,
            p_ly_do_khac,
            p_ld_tang,
            p_loai_dn,
            p_lt_hsl,
            p_lt_nt,
            p_lt_vnd,
            p_ma,
            p_ma_dvt,
            p_ms_thue,
            TO_DATE(
                p_ngay_dkkd,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            TO_DATE(
                p_ngay_giam,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            TO_DATE(
                p_ngay_tang,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_nguoi_dd,
            p_ns_ht,
            TO_DATE(
                p_nsinh_ndd,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_phuong_thuc,
            p_quy_doi,
            p_so_dinh_danh,
            p_so_dkkd,
            p_tat_toan,
            p_td_so,
            p_td_the,
            p_ten,
            p_ten_dvcq,
            p_ten_ta,
            p_ten_tat,
            p_tk_gd,
            p_tl_kem_theo,
            p_yt_ml,
            p_ns_htro_khac,
            TO_DATE(
                p_ngay_dung_tl,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_don_vi_dong,
            p_email,
            p_nguoi_lh,
            p_sdt_nguoi_lh,
            p_email_nguoi_lh,
            TO_DATE(
                p_ngay_tattoan,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_huu_tri,
            p_dm_bhxh_id,
            p_dm_dbhc_id,
            p_dm_dt_kcb_id,
            p_dm_khoi_kcb_id,
            p_dm_khoi_ql_id,
            p_dm_ngoai_te_id,
            p_dm_vung_id,
            p_ma_huyen_kcb_id,
            p_ma_tinh_kcb_id,
            p_ma_xa_kcb_id,
            p_qtich_ndd_id,
            p_user_id,
            p_ma_dvt_cu,
            p_thang_tl,
            p_ty_le_nsnn,
            p_is_dvi_no,
            TO_DATE(
                p_ngay_dvi_no,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_user_dvi_no_id,
            p_md5
        );

        p_output_msg := 'Insert success id =' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_don_vi;
/
