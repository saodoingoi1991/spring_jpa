CREATE PROCEDURE get_dm_dbhc (
    p_ma_dbhc     IN VARCHAR2,
    p_recordset   OUT SYS_REFCURSOR
)
    AS
BEGIN
    IF
        p_ma_dbhc IS NULL
    THEN
        OPEN p_recordset FOR
            SELECT
                *
            FROM
                common_dm_dbhc;

    ELSE
        OPEN p_recordset FOR
            SELECT
                *
            FROM
                common_dm_dbhc
            WHERE
                ma_dbhc = p_ma_dbhc;

    END IF;
END get_dm_dbhc;
/
