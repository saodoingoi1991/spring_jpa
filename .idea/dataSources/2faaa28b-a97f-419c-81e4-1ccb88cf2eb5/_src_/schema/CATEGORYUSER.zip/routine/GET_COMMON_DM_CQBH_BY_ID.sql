CREATE PROCEDURE get_common_dm_cqbh_by_id (
    p_id            IN NUMBER,
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2,
    p_out_table     OUT SYS_REFCURSOR
) IS
    p_count   NUMBER := 0;
BEGIN
    p_output_code := '00';
    p_output_msg := 'Thanh cong';
    OPEN p_out_table FOR
        SELECT
            id,
            ma_cqbh_tinh AS ma,
            ten_cqbh_tinh AS ten
        FROM
            common_dm_cqbh_tinh
        WHERE
            id = p_id
        UNION
        SELECT
            id,
            ma_cqbh_huyen AS ma,
            ten_cqbh_huyen AS ten
        FROM
            common_dm_cqbh_huyen
        WHERE
            id = p_id;

    FOR arow IN (
        SELECT
            id,
            ma_cqbh_tinh AS ma,
            ten_cqbh_tinh AS ten
        FROM
            common_dm_cqbh_tinh
        WHERE
            id = p_id
        UNION
        SELECT
            id,
            ma_cqbh_huyen AS ma,
            ten_cqbh_huyen AS ten
        FROM
            common_dm_cqbh_huyen
        WHERE
            id = p_id
    ) LOOP
        p_count := p_count + 1;
    END LOOP;

    IF
        ( p_count > 1 )
    THEN
        p_output_code := '01';
        p_output_msg := 'So luong ban ghi lon hon 1';
    END IF;

    IF
        ( p_count = 0 )
    THEN
        p_output_code := '02';
        p_output_msg := 'Khong tim thay du lieu';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            1500
        );
        p_out_table := NULL;
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            'get_common_dm_cqbh_by_id_' || p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END get_common_dm_cqbh_by_id;
/
