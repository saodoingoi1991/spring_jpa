CREATE PROCEDURE get_common_dm_cqbh_by_ma (
    p_ma            IN NUMBER,
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2,
    p_out_table     OUT SYS_REFCURSOR
) IS
    p_count   NUMBER := 0;
BEGIN
    p_output_code := '00';
    p_output_msg := 'Thanh cong';
    OPEN p_out_table FOR
        SELECT 
            h.ID, 
            h.MA_CQBH_HUYEN, 
            h.TEN_CQBH_HUYEN,
            h.MA_CQBH_TINH, 
            t.TEN_CQBH_TINH
        FROM COMMON_DM_CQBH_HUYEN h
        INNER JOIN COMMON_DM_CQBH_TINH t
        ON h.MA_CQBH_TINH = t.MA_CQBH_TINH
        AND (t.id=p_ma OR h.id =p_ma);
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            1500
        );
        p_out_table := NULL;
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            'get_common_dm_cqbh_by_id_' || p_output_code,
            p_output_msg,
            p_ma
        );

        COMMIT;
END get_common_dm_cqbh_by_ma;
/
