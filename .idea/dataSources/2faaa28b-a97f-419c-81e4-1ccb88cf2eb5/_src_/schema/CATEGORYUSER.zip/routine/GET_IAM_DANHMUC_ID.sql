CREATE PROCEDURE GET_IAM_DANHMUC_ID(p_recordset OUT SYS_REFCURSOR) AS 
BEGIN
  OPEN p_recordset FOR
  select * from IAM_DANHMUC_ID;
  --close p_recordset;
END GET_IAM_DANHMUC_ID;
/
