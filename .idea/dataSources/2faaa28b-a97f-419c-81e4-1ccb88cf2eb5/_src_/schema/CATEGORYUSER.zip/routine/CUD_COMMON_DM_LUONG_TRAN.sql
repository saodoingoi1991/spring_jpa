CREATE PROCEDURE cud_common_dm_luong_tran (
    p_id               IN NUMBER,
    p_dm_ngoai_te_id   IN NUMBER,
    p_thang            IN VARCHAR2,--date
    p_muc_luong_yt     IN VARCHAR2,
    p_muc_luong        IN VARCHAR2,
    p_output_code      OUT VARCHAR2,
    p_output_msg       OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN
    --update
        UPDATE common_dm_luong_tran
            SET
                dm_ngoai_te_id = p_dm_ngoai_te_id,
                thang = TO_DATE(
                    p_thang,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                muc_luong_yt = p_muc_luong_yt,
                muc_luong = p_muc_luong
        WHERE
            id = p_id;

        p_output_msg := 'Update success id =' || p_id;
        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;
    ELSE
    --insert
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_luong_tran;

        INSERT INTO common_dm_luong_tran (
            id,
            dm_ngoai_te_id,
            thang,
            muc_luong_yt,
            muc_luong
        ) VALUES (
            id_value,
            p_dm_ngoai_te_id,
            TO_DATE(
                p_thang,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_muc_luong_yt,
            p_muc_luong
        );

        p_output_msg := 'Insert success id=' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_luong_tran;
/
