CREATE FUNCTION GET_DM (p_loc VARCHAR2, p_job VARCHAR2)  RETURN NUMBER
IS
  v_query_str VARCHAR2(1000);
  v_num_of_employees NUMBER;
BEGIN
  v_query_str := ' SELECT COUNT(*) INTO :into_bind FROM common_dm_khoi_quan_ly';
  EXECUTE IMMEDIATE v_query_str into v_num_of_employees using p_job;
   -- USING out v_num_of_employees, p_job;
  RETURN v_num_of_employees;
END;
/
