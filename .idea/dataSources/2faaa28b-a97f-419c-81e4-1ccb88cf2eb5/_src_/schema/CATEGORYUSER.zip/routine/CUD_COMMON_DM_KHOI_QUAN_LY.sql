CREATE PROCEDURE cud_common_dm_khoi_quan_ly (
    p_id               IN NUMBER,
    p_ma               IN VARCHAR2,
    p_ten              IN VARCHAR2,
    p_dm_bhxh_id       IN NUMBER,
    p_dm_khoi_kcb_id   IN NUMBER,
    p_dm_khoi_tk_id    IN NUMBER,
    p_status           IN NUMBER,
    p_bhyt             IN NUMBER,
    p_output_code      OUT VARCHAR2,
    p_output_msg       OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN
        UPDATE common_dm_khoi_quan_ly
            SET
                updated_date = SYSDATE,
                ma = p_ma,
                ten = p_ten,
                dm_bhxh_id = p_dm_bhxh_id,
                dm_khoi_kcb_id = p_dm_khoi_kcb_id,
                dm_khoi_tk_id = p_dm_khoi_tk_id,
                status = p_status,
                bhyt = p_bhyt
        WHERE
            id = p_id;

        p_output_msg := 'Update success id =' || p_id;
        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;

    ELSE
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_khoi_quan_ly;

        INSERT INTO common_dm_khoi_quan_ly (
            id,
            created_date,
            updated_date,
            ma,
            ten,
            dm_bhxh_id,
            dm_khoi_kcb_id,
            dm_khoi_tk_id,
            status,
            bhyt
        ) VALUES (
            id_value,
            SYSDATE,
            SYSDATE,
            p_ma,
            p_ten,
            p_dm_bhxh_id,
            p_dm_khoi_kcb_id,
            p_dm_khoi_tk_id,
            p_status,
            p_bhyt
        );

        p_output_msg := 'Insert success id = ' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_khoi_quan_ly;
/
