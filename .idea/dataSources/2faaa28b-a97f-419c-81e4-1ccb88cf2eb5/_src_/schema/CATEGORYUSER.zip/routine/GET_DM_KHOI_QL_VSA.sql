CREATE PROCEDURE get_dm_khoi_ql_vsa (
    p_ma_bhxh        IN VARCHAR,
    p_updated_date   IN VARCHAR2,
    p_recordset      OUT SYS_REFCURSOR
)
    AS
BEGIN    
/**
Sua check p_ma_bhxh co ton tai khong
*/
    IF
        p_updated_date IS NULL
    THEN
        OPEN p_recordset FOR
            SELECT
                ql.ma,
                ql.ten,
                b.ma makhoikcb
            FROM
                common_dm_khoi_quan_ly ql
                LEFT JOIN common_dm_khoi_kcb b ON ql.dm_khoi_kcb_id = b.id
                LEFT JOIN tst_bhxh_mapping t ON ql.dm_bhxh_id = t.id_cqbh_tst
            WHERE
                    t.ma_cqbh_tst = p_ma_bhxh
                OR
                    t.ma_cqbh_tst = '0003';

    ELSE
        OPEN p_recordset FOR
            SELECT
                ql.ma,
                ql.ten,
                b.ma makhoikcb
            FROM
                common_dm_khoi_quan_ly ql
                LEFT JOIN common_dm_khoi_kcb b ON ql.dm_khoi_kcb_id = b.id
                LEFT JOIN tst_bhxh_mapping t ON ql.dm_bhxh_id = t.id_cqbh_tst
            WHERE
                (
                        t.ma_cqbh_tst = p_ma_bhxh
                    OR
                        t.ma_cqbh_tst = '0003'
                ) AND
                    p_updated_date = (
                        CASE
                            WHEN p_updated_date LIKE '____' THEN TO_CHAR(
                                ql.updated_date,
                                'yyyy'
                            )
                            WHEN p_updated_date LIKE '______' THEN TO_CHAR(
                                ql.updated_date,
                                'yyyyMM'
                            )
                        END
                    );

    END IF;
END get_dm_khoi_ql_vsa;
/
