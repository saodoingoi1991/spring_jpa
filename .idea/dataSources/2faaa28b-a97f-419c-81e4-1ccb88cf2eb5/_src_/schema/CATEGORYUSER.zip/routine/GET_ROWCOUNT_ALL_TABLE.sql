CREATE PROCEDURE get_rowcount_all_table (
    p_output_code   OUT VARCHAR2,
    p_output_msg    OUT VARCHAR2,
    p_out_table     OUT SYS_REFCURSOR
)
    IS
BEGIN
    p_output_code := '00';
    p_output_msg := 'Thanh cong';
    OPEN p_out_table FOR
        SELECT
            ROW_NUMBER() OVER(
                ORDER BY table_name
            ) AS id,
            table_name,
            to_number(extractvalue(
                xmltype(dbms_xmlgen.getxml('select count(*) c from '
                 || table_name) ),
                '/ROWSET/ROW/C'
            ) ) count
        FROM
            user_tables;

END get_rowcount_all_table;
/
