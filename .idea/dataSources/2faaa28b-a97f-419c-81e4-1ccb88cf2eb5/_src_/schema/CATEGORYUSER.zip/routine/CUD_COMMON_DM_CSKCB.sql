CREATE PROCEDURE cud_common_dm_cskcb (
    p_id                    IN NUMBER,
    p_ten                   IN NVARCHAR2,
    p_ma                    IN VARCHAR2,
    p_mabhyt                IN VARCHAR2,
    p_donvihanhchinh_id     IN NUMBER,
    p_diachi                IN VARCHAR2,
    p_hangbenhvien          IN NUMBER,
    p_tuyencmkt             IN NUMBER,
    p_hieuluc               IN NUMBER,
    p_mieuta                IN NVARCHAR2,
    p_stt                   IN NUMBER,
    p_tinhthanh_id          IN NUMBER,
    p_quanhuyen_id          IN NUMBER,
    p_matinhthanh           IN VARCHAR2,
    p_maquanhuyen           IN VARCHAR2,
    p_donvi_id              IN NUMBER,
    p_macosokcbcha          IN VARCHAR2,
    p_cosokcbcha_id         IN NUMBER,
    p_madonvi               IN VARCHAR2,
    p_thannhantao           IN NUMBER,
    p_thaighep              IN NUMBER,
    p_loaihopdong           IN NUMBER,
    p_dkkcbbd               IN NUMBER,
    p_hinhthuctt            IN NUMBER,
    p_loaibenhvien          IN NUMBER,
    p_khamtreem             IN NUMBER,
    p_ngayngunghd           IN VARCHAR2,--date
    p_mataichinh            IN VARCHAR2,
    p_pkdakhoa              IN NUMBER,
    p_ungthu                IN NUMBER,
    p_viemgan               IN NUMBER,
    p_tebaomautd            IN NUMBER,
    p_khamt7                IN NUMBER,
    p_khamcn                IN NUMBER,
    p_khamngayle            IN NUMBER,
    p_masothue              IN VARCHAR2,
    p_dienthoai             IN VARCHAR2,
    p_email                 IN VARCHAR2,
    p_fax                   IN VARCHAR2,
    p_coquanchuquan         IN VARCHAR2,
    p_ngaykyhopdong         IN VARCHAR2,--date
    p_kieubv                IN NUMBER,
    p_capcskcb_min          IN NUMBER,
    p_ttpheduyet            IN NUMBER,
    p_sohopdong             IN NVARCHAR2,
    p_lydo                  IN NVARCHAR2,
    p_trangthai             IN NUMBER,
    p_tuchu                 IN NUMBER,
    p_hangdichvu_td         IN NUMBER,
    p_hangthuoc_td          IN NUMBER,
    p_hangvattu_td          IN NUMBER,
    p_byt                   IN NUMBER,
    p_so_gphd               IN NVARCHAR2,
    p_kcb                   IN NUMBER,
    p_ngaycapma             IN VARCHAR2,--date
    p_ngaydieuchinh         IN VARCHAR2,--date
    p_loai_donvichuquan     IN NUMBER,
    p_chua_pd43             IN NUMBER,
    p_ngaykyhopdonglandau   IN VARCHAR2,--date
    p_ghichu_tinhthaydoi    IN VARCHAR2,
    p_sl_the_bh_dkbd        IN NUMBER,
    p_sl_the_bh_da_cap      IN NUMBER,
    p_loai_ck               IN NUMBER,
    p_output_code           OUT VARCHAR2,
    p_output_msg            OUT VARCHAR2
) IS
    id_value   NUMBER;
BEGIN
    IF
        p_id IS NOT NULL
    THEN            
        --Update 
        UPDATE common_dm_cskcb
            SET
                ten = p_ten,
                ma = p_ma,
                mabhyt = p_mabhyt,
                donvihanhchinh_id = p_donvihanhchinh_id,
                diachi = p_diachi,
                hangbenhvien = p_hangbenhvien,
                tuyencmkt = p_tuyencmkt,
                hieuluc = p_hieuluc,
                mieuta = p_mieuta,
                stt = p_stt,
                tinhthanh_id = p_tinhthanh_id,
                quanhuyen_id = p_quanhuyen_id,
                matinhthanh = p_matinhthanh,
                maquanhuyen = p_maquanhuyen,
                donvi_id = p_donvi_id,
                macosokcbcha = p_macosokcbcha,
                cosokcbcha_id = p_cosokcbcha_id,
                madonvi = p_madonvi,
                thannhantao = p_thannhantao,
                thaighep = p_thaighep,
                loaihopdong = p_loaihopdong,
                dkkcbbd = p_dkkcbbd,
                hinhthuctt = p_hinhthuctt,
                loaibenhvien = p_loaibenhvien,
                khamtreem = p_khamtreem,
                ngayngunghd = TO_DATE(
                    p_ngayngunghd,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                mataichinh = p_mataichinh,
                pkdakhoa = p_pkdakhoa,
                ungthu = p_ungthu,
                viemgan = p_viemgan,
                tebaomautd = p_tebaomautd,
                khamt7 = p_khamt7,
                khamcn = p_khamcn,
                khamngayle = p_khamngayle,
                masothue = p_masothue,
                dienthoai = p_dienthoai,
                email = p_email,
                fax = p_fax,
                coquanchuquan = p_coquanchuquan,
                ngaykyhopdong = TO_DATE(
                    p_ngaykyhopdong,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                kieubv = p_kieubv,
                capcskcb_min = p_capcskcb_min,
                ttpheduyet = p_ttpheduyet,
                sohopdong = p_sohopdong,
                lydo = p_lydo,
                trangthai = p_trangthai,
                tuchu = p_tuchu,
                hangdichvu_td = p_hangdichvu_td,
                hangthuoc_td = p_hangthuoc_td,
                hangvattu_td = p_hangvattu_td,
                byt = p_byt,
                so_gphd = p_so_gphd,
                kcb = p_kcb,
                ngaycapma = TO_DATE(
                    p_ngaycapma,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                ngaydieuchinh = TO_DATE(
                    p_ngaydieuchinh,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                loai_donvichuquan = p_loai_donvichuquan,
                chua_pd43 = p_chua_pd43,
                ngaykyhopdonglandau = TO_DATE(
                    p_ngaykyhopdonglandau,
                    'dd-mm-yyyy HH24:mi:ss'
                ),
                ghichu_tinhthaydoi = p_ghichu_tinhthaydoi,
                sl_the_bh_dkbd = p_sl_the_bh_dkbd,
                sl_the_bh_da_cap = p_sl_the_bh_da_cap,
                loai_ck = p_loai_ck
        WHERE
            id = p_id;

--        p_output_msg := 'Update success id =' || p_id;

        IF
            SQL%rowcount > 0
        THEN
            p_output_msg := 'Update success id =' || p_id;
        ELSE
            p_output_msg := '0 rows affected. id =' || p_id;
        END IF;

    ELSE
        SELECT
            CASE
                WHEN MAX(id) IS NULL THEN 1
                ELSE ( MAX(id) + 1 )
            END
        INTO
            id_value
        FROM
            common_dm_cskcb;
         --Insert          

        INSERT INTO common_dm_cskcb (
            id,
            ten,
            ma,
            mabhyt,
            donvihanhchinh_id,
            diachi,
            hangbenhvien,
            tuyencmkt,
            hieuluc,
            mieuta,
            stt,
            tinhthanh_id,
            quanhuyen_id,
            matinhthanh,
            maquanhuyen,
            donvi_id,
            macosokcbcha,
            cosokcbcha_id,
            madonvi,
            thannhantao,
            thaighep,
            loaihopdong,
            dkkcbbd,
            hinhthuctt,
            loaibenhvien,
            khamtreem,
            ngayngunghd,
            mataichinh,
            pkdakhoa,
            ungthu,
            viemgan,
            tebaomautd,
            khamt7,
            khamcn,
            khamngayle,
            masothue,
            dienthoai,
            email,
            fax,
            coquanchuquan,
            ngaykyhopdong,
            kieubv,
            capcskcb_min,
            ttpheduyet,
            sohopdong,
            lydo,
            trangthai,
            tuchu,
            hangdichvu_td,
            hangthuoc_td,
            hangvattu_td,
            byt,
            so_gphd,
            kcb,
            ngaycapma,
            ngaydieuchinh,
            loai_donvichuquan,
            chua_pd43,
            ngaykyhopdonglandau,
            ghichu_tinhthaydoi,
            sl_the_bh_dkbd,
            sl_the_bh_da_cap,
            loai_ck
        ) VALUES (
            id_value,
            p_ten,
            p_ma,
            p_mabhyt,
            p_donvihanhchinh_id,
            p_diachi,
            p_hangbenhvien,
            p_tuyencmkt,
            p_hieuluc,
            p_mieuta,
            p_stt,
            p_tinhthanh_id,
            p_quanhuyen_id,
            p_matinhthanh,
            p_maquanhuyen,
            p_donvi_id,
            p_macosokcbcha,
            p_cosokcbcha_id,
            p_madonvi,
            p_thannhantao,
            p_thaighep,
            p_loaihopdong,
            p_dkkcbbd,
            p_hinhthuctt,
            p_loaibenhvien,
            p_khamtreem,
            TO_DATE(
                p_ngayngunghd,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_mataichinh,
            p_pkdakhoa,
            p_ungthu,
            p_viemgan,
            p_tebaomautd,
            p_khamt7,
            p_khamcn,
            p_khamngayle,
            p_masothue,
            p_dienthoai,
            p_email,
            p_fax,
            p_coquanchuquan,
            TO_DATE(
                p_ngaykyhopdong,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_kieubv,
            p_capcskcb_min,
            p_ttpheduyet,
            p_sohopdong,
            p_lydo,
            p_trangthai,
            p_tuchu,
            p_hangdichvu_td,
            p_hangthuoc_td,
            p_hangvattu_td,
            p_byt,
            p_so_gphd,
            p_kcb,
            TO_DATE(
                p_ngaycapma,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            TO_DATE(
                p_ngaydieuchinh,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_loai_donvichuquan,
            p_chua_pd43,
            TO_DATE(
                p_ngaykyhopdonglandau,
                'dd-mm-yyyy HH24:mi:ss'
            ),
            p_ghichu_tinhthaydoi,
            p_sl_the_bh_dkbd,
            p_sl_the_bh_da_cap,
            p_loai_ck
        );

        p_output_msg := 'Insert success id =' || id_value;
    END IF;

    COMMIT;
    p_output_code := '00';
EXCEPTION
    WHEN OTHERS THEN
        p_output_code := sqlcode;
        p_output_msg := substr(
            sqlerrm,
            1,
            2000
        );
        INSERT INTO procedure_log (
            id,
            error_code,
            message,
            id_entity
        ) VALUES (
            (
                SELECT
                    MAX(id) + 1
                FROM
                    procedure_log
            ),
            p_output_code,
            p_output_msg,
            p_id
        );

        COMMIT;
END cud_common_dm_cskcb;
/
