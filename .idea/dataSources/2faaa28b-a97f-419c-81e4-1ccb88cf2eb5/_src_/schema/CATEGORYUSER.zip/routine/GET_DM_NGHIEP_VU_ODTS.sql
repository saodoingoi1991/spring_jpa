CREATE PROCEDURE get_dm_nghiep_vu_odts ( p_recordset   OUT SYS_REFCURSOR )
    AS
BEGIN
    OPEN p_recordset FOR
        SELECT
            *
        FROM
            common_dm_nghiep_vu;

END get_dm_nghiep_vu_odts;
/
