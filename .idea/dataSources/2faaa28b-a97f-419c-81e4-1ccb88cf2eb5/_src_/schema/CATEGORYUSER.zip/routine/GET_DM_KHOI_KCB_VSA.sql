CREATE PROCEDURE get_dm_khoi_kcb_vsa ( p_recordset   OUT SYS_REFCURSOR )
    AS
BEGIN
    OPEN p_recordset FOR
        SELECT
            ma,
            ten,
            dm_dt_kcb_id
        FROM
            common_dm_khoi_kcb;

END get_dm_khoi_kcb_vsa;
/
