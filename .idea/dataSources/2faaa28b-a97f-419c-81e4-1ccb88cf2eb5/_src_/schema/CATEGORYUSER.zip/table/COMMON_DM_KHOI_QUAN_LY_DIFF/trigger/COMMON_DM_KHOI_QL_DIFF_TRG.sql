CREATE TRIGGER COMMON_DM_KHOI_QL_DIFF_TRG
BEFORE INSERT
  ON COMMON_DM_KHOI_QUAN_LY_DIFF
FOR EACH ROW
  BEGIN
    BEGIN
        IF
            inserting AND
                :new.verify_id IS NULL
        THEN
            SELECT
                common_dm_khoi_ql_diff_seq.NEXTVAL
            INTO
                :new.verify_id
            FROM
                dual;

        END IF;

    END column_sequences;
END;
/
