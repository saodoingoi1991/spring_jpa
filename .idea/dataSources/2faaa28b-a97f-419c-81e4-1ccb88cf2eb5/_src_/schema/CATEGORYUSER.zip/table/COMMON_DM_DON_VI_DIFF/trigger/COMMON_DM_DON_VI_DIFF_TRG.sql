CREATE TRIGGER COMMON_DM_DON_VI_DIFF_TRG
BEFORE INSERT
  ON COMMON_DM_DON_VI_DIFF
FOR EACH ROW
  BEGIN
    BEGIN
        IF
            inserting AND
                :new.verify_id IS NULL
        THEN
            SELECT
                common_dm_don_vi_diff_seq.NEXTVAL
            INTO
                :new.verify_id
            FROM
                dual;

        END IF;

    END column_sequences;
END;
/
