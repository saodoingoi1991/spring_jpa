CREATE TRIGGER COMMON_DM_CSKCB_DIFF_TRG
BEFORE INSERT
  ON COMMON_DM_CSKCB_DIFF
FOR EACH ROW
  BEGIN
    << column_sequences >> BEGIN
        IF
            inserting AND
                :new.verify_id IS NULL
        THEN
            SELECT
                common_dm_cskcb_diff_seq.NEXTVAL
            INTO
                :new.verify_id
            FROM
                sys.dual;

        END IF;
    END column_sequences;
END;
/
