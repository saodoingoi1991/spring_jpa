CREATE TRIGGER COMMON_DM_PHONG_BAN_DIFF_TRG
BEFORE INSERT
  ON COMMON_DM_PHONG_BAN_DIFF
FOR EACH ROW
  BEGIN
    BEGIN
        IF
            inserting AND
                :new.verify_id IS NULL
        THEN
            SELECT
                COMMON_DM_PHONG_BAN_DIFF_SEQ.NEXTVAL
            INTO
                :new.verify_id
            FROM
                dual;

        END IF;

    END column_sequences;
END;
/
