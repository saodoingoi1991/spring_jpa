CREATE TYPE object_common_dm_khoi_quan_ly AS OBJECT (
    id               NUMBER(19),
    created_date     TIMESTAMP(6),
    updated_date     TIMESTAMP(6),
    ma               VARCHAR2(2 CHAR),
    ten              VARCHAR2(150),
    dm_bhxh_id       NUMBER(19),
    dm_khoi_kcb_id   NUMBER(19),
    dm_khoi_tk_id    NUMBER(19),
    status           NUMBER(1),
    bhyt             NUMBER(1)
);
/
